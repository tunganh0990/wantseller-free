# WantSeller Free — đặc tả tái dựng và phát hành

**Bản tham chiếu:** WantSeller 1.5.0 (bộ cài 1.4.2 và ứng dụng đã cập nhật). **Sản phẩm đích:** WantSeller Free, ứng dụng desktop Windows x64 miễn phí, tái dựng giao diện và luồng nghiệp vụ đã quan sát được, đồng thời bổ sung công cụ vận hành cho người bán. Người dùng xác nhận quyền mua cho phép sao chép, sửa đổi và phát hành công khai giao diện/tài sản liên quan; phạm vi giấy phép phải được ghi rõ ở repo. Mã mới không có kiểm tra HWID, mã cấp phép hay máy chủ xác thực. Tài khoản sàn, nếu được tích hợp sau này, vẫn phải dùng luồng OAuth/API chính thức của sàn.

Tài liệu phân biệt **đã triển khai trong mã hiện tại**, **mục tiêu của bản tiếp theo** và **điều kiện cần để mở tích hợp thật**. Không coi nút giao diện là tích hợp hoàn chỉnh nếu chưa có adapter, quyền API và dữ liệu đồng bộ kiểm chứng được.

## 1. Phạm vi và quyết định sản phẩm

| Phạm vi | Đã có trong 0.1.0 | Mục tiêu phát hành hoàn chỉnh |
|---|---|---|
| Nền tảng desktop | Electron shell, điều hướng, CRUD shop cục bộ, tổng quan doanh thu/lãi 7 ngày, cài đặt về lưu trữ/quyền riêng tư | Workspace nhiều tab, kết nối OAuth chính thức, thông báo bền vững và cập nhật |
| Đơn hàng | Nhập/xuất CSV, tìm kiếm, lọc trạng thái, tổng doanh thu/lãi và biểu đồ 7 ngày; nhắc rà soát đơn có chi phí bằng 0 | Đồng bộ đơn, chi tiết, lọc hạn, batch đi đơn, đối soát và lịch sử thao tác khi sàn cấp quyền |
| Kho phiếu in | Danh mục PDF cục bộ, gắn shop, lập chỉ mục text theo trang, tìm mã, xem trước và mở ngoài app | OCR scan, giám sát tệp đổi chỗ, batch in và lưu bản sao |
| Chat | Mẫu trả lời lưu cục bộ, chỉnh và sao chép để dán | Inbox đa sàn theo API, lịch sử hội thoại, ngữ cảnh đơn, gửi có trạng thái và thao tác được cấp quyền |
| Tự động hóa | Lưu kế hoạch nháp cho Boost, Flash Sale, đánh giá và phản hồi chat | Rule editor, kiểm tra trước chạy, lịch cục bộ, nhật ký và gọi API sau xác nhận |
| Tính năng miễn phí nâng cao | Ước tính lãi theo phí/vốn/vận chuyển; nhập/xuất đa shop; thư viện mẫu; kế hoạch nháp | Cảnh báo SLA/tồn kho, báo cáo lãi theo shop/SKU, đối chiếu phí, phát hiện bất thường và batch an toàn |
| Giấy phép và quyền riêng tư | Không có HWID/licensing gate; DB riêng trong `%APPDATA%\\WantSeller-Free`; chưa gửi dữ liệu từ shop lên máy chủ | Giữ miễn phí, không telemetry mặc định; mọi tích hợp ngoài phải minh bạch, có cấu hình và dùng API chính thức |

Giữ bố cục điều hướng và tên các module của WantSeller 1.5.0: Shop của tôi, Xử lý đơn hàng, Quản lý file in, Chat đa sàn, Đẩy sản phẩm, Flash Sale, Tự động đánh giá, Tự động trả lời chat và Cài đặt. Màn hiện tại dùng một shell React/TypeScript; bổ sung module theo giai đoạn để không giả lập kết nối. Chức năng không có API được duyệt phải có trạng thái nháp hoặc thao tác thủ công. Không dùng cookie phiên lấy từ ứng dụng gốc làm đầu vào cho tích hợp mới.

## 2. Stack và nơi đặt trách nhiệm

| Lớp | Công nghệ chốt trong repo | Vai trò và quyết định |
|---|---|---|
| Node và gói | Node.js 26.13.1 cho tooling, npm và lockfile; Electron đóng gói runtime riêng | `.node-version` khóa tooling. Tránh native dependency chưa cần thiết để người dùng build không cần Visual Studio C++ |
| Desktop | Electron 45.5.0, `electron-vite`, `electron-builder`, NSIS per-user | Main, preload CommonJS và renderer được đóng gói thành app Windows x64. Sửa `userData` sang `WantSeller-Free` để tách DB khỏi bản tham chiếu |
| Giao diện | React 19, TypeScript strict, CSS thuần với custom properties, Lucide React | Shell theo bố cục tham chiếu. State React điều phối route/filter; màn con tự tải dữ liệu qua IPC. Chưa thêm router/query/table dependency |
| Hợp đồng | Zod 4 + TypeScript | Validate shop, UUID, template, kế hoạch và payload nhập ở main. Preload chỉ expose API đặt tên rõ; không đưa `ipcRenderer` vào renderer |
| Dữ liệu desktop | `node:sqlite` `DatabaseSync` tích hợp trong runtime Electron; WAL, FK, prepared statements | Mọi DB access ở main. Tables: shops, settings, orders, print_documents, print_document_pages, reply_templates, automation_plans và schema_migrations. SQLite là API release-candidate; kiểm tra runtime Electron trước mỗi lần nâng cấp |
| Tệp và PDF | Windows dialog, `fs/promises`, `shell.openPath`, PDF.js 6.5 | PDF giữ nguyên vị trí gốc; app ghi metadata, index text theo trang trong SQLite, tìm và preview canvas. Không OCR scan |
| Kết nối sàn | Chưa có adapter/gateway | Chỉ triển khai OAuth/API được sàn duyệt. Không dùng cookie/session, endpoint riêng của bản gốc hoặc HWID service |
| Kiểm thử và phát hành | TypeScript compiler, `electron-vite build`, NSIS x64, GitHub Actions Windows workflow | Typecheck/build, smoke PDF và `npm audit` (0 lỗ hổng) đã qua. Installer NSIS x64 0.1.0 đã tạo, checksum lưu trong release notes; chưa có Authenticode, cài sạch hoặc E2E tự động |

Dùng renderer nội bộ với `nodeIntegration: false`, `contextIsolation: true`, `sandbox: true`. Preload CommonJS khai báo từng thao tác; main validate payload bằng Zod. Cửa sổ chặn navigation ngoài nguồn ứng dụng và chặn popup. Khi bổ sung OAuth, mở trình duyệt hệ thống theo URL HTTPS allowlist rồi xác minh callback/state. Không lưu mật khẩu/cookie sàn vào SQLite. [Hướng dẫn bảo mật Electron](https://www.electronjs.org/docs/latest/tutorial/security)

### 2.1 Tổ chức mã nguồn

```text
WantSeller-Free/
  build/icon.ico
  src/
    main/
      index.ts                 # BrowserWindow, Zod IPC, CSV dialog/import, PDF registry
      database.ts              # SQLite schema, repositories and local-only data
    preload/index.ts           # minimal typed bridge, CommonJS output for sandbox
    renderer/
      index.html
      assets/reference/        # logos and UI files authorized for public reproduction
      src/
        App.tsx                # desktop shell, sidebar, shops, dashboard, add-shop form
        Features.tsx           # order CSV, PDF registry, chat snippets, plan editors, settings
        styles.css             # shell and module styles
        vite-env.d.ts          # renderer bridge types
  electron.vite.config.ts
  electron-builder.yml
  package.json / package-lock.json
  README.md / LICENSE / THIRD_PARTY_NOTICES.md
```

Hiện repo là một gói desktop đơn, chưa tách workspace. Renderer chỉ gọi `window.wantSeller`; main là chủ sở hữu DB, đường dẫn, hộp chọn tệp và mở PDF. Chuyển `Features.tsx` thành feature folder khi mỗi module có nhiều màn con. Chỉ đưa gateway vào repo khi API chính thức đòi backend giữ client secret, webhook hoặc phân quyền workspace; không cần gateway cho import/export offline. Giao diện không gửi dữ liệu cá nhân của shop đến máy chủ.

### 2.2 Tạo dự án và kiểm tra chạy được

1. Cài đúng Node ghi trong `.node-version`, chạy `npm ci`, mở shell bằng `npm run dev`.
2. Chạy `npm run typecheck` để kiểm tra TypeScript, `npm run build` để biên dịch main/preload/renderer.
3. Tạo bộ cài Windows với `npm run dist:win`; output nằm trong `release/` và app lưu DB ở thư mục user data riêng.
4. Trước phát hành, kiểm tra cài mới/nâng cấp, DB ở đường dẫn có dấu và dấu cách, import/export CSV UTF-8, file PDF bị di chuyển, và xác minh gói không chứa dữ liệu profile WantSeller cũ.

```powershell
npm.cmd ci
npm.cmd run dev
npm.cmd run typecheck
npm.cmd run build
npm.cmd run dist:win
```

Lockfile được commit, CI dùng `npm ci`. Hiện không có native build dependency. NSIS cài theo user; chương trình cài trong thư mục ứng dụng, SQLite và cài đặt nằm ở `%APPDATA%\\WantSeller-Free`. [Đóng gói NSIS bằng electron-builder](https://www.electron.build/nsis.html)

## 3. Thiết kế giao diện

### 3.1 Khung ứng dụng và quy chuẩn

Thiết kế theo shell Windows quan sát ở bản 1.5.0: thanh tiêu đề native, thanh thương hiệu 38 px, toolbar 48 px, sidebar 254 px và vùng nội dung cuộn độc lập. Cửa sổ mặc định 1420 × 900, tối thiểu 1024 × 680. Dùng Segoe UI, văn bản shell 11–13 px, tiêu đề trang 21 px, heading module 16 px, nhãn/metadata 9–10 px. Khoảng cách theo lưới 4 px, hàng điều hướng 36 px, nút chính 34 px. Bảng dài cuộn trong vùng nội dung.

Bảng màu bám giao diện tham chiếu: canvas `#F5F6F8`, panel `#FFFFFF`, chữ `#252A34`, phụ `#858B96`, viền `#E6E8EC`, hành động cam `#EE4D2D`, hover đậm `#D63E20`, thành công `#20A56B`. Badge miễn phí dùng nền hồng nhạt và chữ cam. Sidebar trắng, mục đang chọn nền `#FFF1ED`. Icon sàn dùng tài sản đã được người dùng xác nhận quyền phát hành. Cảnh báo, lỗi, thành công luôn có chữ bên cạnh màu. Shell runtime dùng CSS viết lại trong `src/renderer/src/styles.css`; CSS tham chiếu nằm trong `src/renderer/assets/reference/` để đối chiếu.

```text
┌ Windows title bar · WantSeller · MIỄN PHÍ · Trợ giúp · Cài đặt · thu nhỏ/đóng ┐
├ ☰ Shop hiện tại │ Quản lý file in │ Chat đa sàn │ Thông báo │ + Thêm shop ┤
│ Sidebar 254 px │ breadcrumb · heading · mô tả · Làm mới · nút chính            │
│ Shop của tôi   │ panel số liệu / tìm kiếm / bảng / editor / file PDF             │
│ Xử lý đơn      │ nội dung theo module, vùng cuộn                                │
│ Quản lý file   │                                                               │
│ Chat đa sàn    │                                                               │
│ Đẩy / Flash    │                                                               │
│ Đánh giá / chat│                                                               │
│ Cài đặt        │                                                               │
└────────────────┴───────────────────────────────────────────────────────────────┘
```

Sidebar hiện rộng 254 px, thu còn 62 px bằng nút ☰; dưới 1100 px toolbar ẩn nhãn shortcut. Lề main 24–28 px. Bản hiện tại chưa có drawer chi tiết hoặc phím tắt toàn cục. Khi thêm thao tác hàng loạt, hộp xác nhận cần nêu số shop/đơn và focus quay về nút mở. Phím đề xuất `Ctrl+K` tìm tính năng, `Ctrl+F` tìm màn hiện tại và `Esc` đóng viewer/modal.

Mỗi màn có đủ trạng thái: đang tải lần đầu, đang làm mới với dữ liệu hiện tại, rỗng, lọc không có kết quả, lỗi tạm thời, mất kết nối, hết quyền và thành công một phần. Lỗi từng dòng hiển thị cạnh đối tượng, với lý do và nút phù hợp. Tác vụ đang xử lý vẫn xem được khi quay lại màn. Nội dung do khách hoặc sàn cung cấp hiển thị dưới dạng text hoặc dữ liệu đã làm sạch, ảnh được tải theo quy tắc nguồn và quyền.

### 3.2 Điều hướng và nút chính

| Route/module | Bố cục và đầu ra | Trạng thái 0.1.0 |
|---|---|---|
| Shop của tôi | Thẻ tổng quan, shortcut, trạng thái và danh sách shop; modal chọn nền tảng/tên | Thêm và xem shop cục bộ; chưa đăng nhập sàn |
| Xử lý đơn | KPI doanh thu/lãi, tìm mã đơn/vận đơn, lọc trạng thái, bảng dữ liệu | CSV nhập/xuất; cập nhật theo shop+mã; chưa đồng bộ/làm batch với sàn |
| Quản lý file in | Danh sách PDF, tìm tên/mã, index text theo trang, kết quả trang, viewer canvas | Nhập ≤50 MB, tối đa 2.000 trang/10 MB text; chưa OCR PDF scan |
| Chat đa sàn | Form mẫu theo nền tảng, danh sách mẫu, sao chép nội dung | CRUD và copy local; chưa có inbox/hội thoại/gửi |
| Đẩy sản phẩm/Flash Sale/Đánh giá/Auto reply | Editor checklist và kho kế hoạch | CRUD nháp; không có scheduler hoặc hành động nền |
| Cài đặt | Phiên bản/miễn phí, thư mục dữ liệu, trạng thái kết nối, quyền riêng tư | Mở userData; chưa có cấu hình kết nối, thông báo, cập nhật |

### 3.3 Shop và phiên làm việc

- **Thêm shop.** Bước 1 chọn Shopee, TikTok Shop, Lazada và vùng. Bước 2 điền tên hiển thị, mở cấp quyền chính thức và chờ callback. Bước 3 xem quyền nhận được, trạng thái và chọn đồng bộ. Cho phép lưu shop chưa kết nối để quản lý thủ công. Tên trùng cùng sàn/vùng được báo trước khi lưu.
- **Sửa shop.** Hiện tên, nhãn, thứ tự, liên kết mặc định và quyền. Nút Kết nối lại cho `expired`, Thu hồi khi đã kết nối, Mở hồ sơ qua hộp chọn của hệ điều hành khi áp dụng. Gỡ shop có bản tóm tắt số job đang chờ và dữ liệu sẽ giữ hoặc dọn theo lựa chọn. Lần chạy đang gửi cần đối soát trước khi gỡ xong.
- **Workspace.** Tab minh bạch shop và sàn, hỗ trợ back/forward, reload, stop, tìm trang, nhân đôi, mở chat, khôi phục sau khi khởi động. Nếu một liên kết nằm ngoài danh sách đã duyệt, hiển thị nút mở ngoài cho người vận hành. Xóa phiên có phạm vi một shop hoặc các shop đã xác nhận, trả trạng thái từng phiên. `WebContentsView` chỉ gắn cho chế độ Seller Center đã chọn, tháo khi đổi route và giới hạn số view sống để quản lý RAM. [Vòng đời và sự kiện WebContents](https://www.electronjs.org/docs/latest/api/web-contents)

### 3.4 Đơn hàng và vận chuyển

Thanh lọc gồm shop, sàn, khoảng ngày, từ khóa, hãng vận chuyển, trạng thái, ghi chú, quá hạn hoặc sắp hết hạn, đặt trước, hỏa tốc, nhóm số sản phẩm và hình thức giao. Bảng hiện ngày tạo, hạn xử lý, đơn, shop, khách đã giảm dữ liệu hiển thị, tên hoặc SKU, số lượng, tổng, vận chuyển, ghi chú và mã vận đơn. Có phân trang 25/50/100, sắp xếp thời gian và tổng số khi sàn trả được. Bộ lọc nhanh cho nhóm giờ 00–18 và 18–24 theo ngày hiện tại hoặc ngày trước, đơn chưa gán thẻ, ghi chú người mua hoặc shop, và đơn do sàn giao. Mốc giờ dùng múi giờ shop.

- **Chi tiết.** Header có số đơn, trạng thái, nguồn, lần đồng bộ. Các khối riêng cho sản phẩm/biến thể, tài chính theo quyền, giao nhận, ghi chú và lịch sử. Hủy đơn yêu cầu lý do nếu sàn trả danh sách lý do, kiểm tra lại trạng thái, xác nhận rồi làm mới dữ liệu.
- **Đi đơn.** Người dùng chọn một hoặc nhiều đơn, chọn sàn/shop phù hợp. Bước xem trước nhóm theo shop và hãng vận chuyển, hiển thị đơn đủ điều kiện và đơn bị loại. Chọn lấy hàng hoặc gửi bưu cục, ngày hẹn nếu khả dụng. Xác nhận để tạo batch ID và tác vụ từng đơn. Bảng tiến độ có thành công, lỗi có thể thử lại, lỗi cần người xử lý và chờ đối soát. Tải lại sau sự cố phải phục hồi màn tiến độ.
- **Đóng hàng/Gửi hàng.** Bản gốc 1.5.0 có nhãn đang phát triển. Thiết kế mới cần tách trạng thái vận hành nội bộ khỏi trạng thái từ sàn. Cho phép đánh dấu đã đóng hoặc bàn giao ở nội bộ khi phù hợp, hiển thị ai thao tác và thời gian. Chuyển trạng thái sàn chỉ bật khi hợp đồng tích hợp được nghiệm thu.
- **Tạo phiếu.** Chọn loại phiếu gửi hoặc phiếu xuất, mẫu A5/A4 bốn ô, in theo phân loại hoặc quy tắc mã nội bộ do người dùng quản lý nếu mẫu hỗ trợ, xem trước và chọn lưu mặc định hoặc Save As. Hiện từng kiện thiếu phiếu. Cột lịch sử ghi đã tạo, đã gửi máy in hoặc lỗi. Tách thời điểm in lại khỏi thời điểm tài liệu gốc được tạo.

### 3.5 Kho phiếu in

Thanh lọc có nền tảng, shop, mốc nhanh và khoảng ngày tùy chỉnh, một/nhiều đơn, ô tìm tên tệp, mã đơn và vận đơn. Danh sách hiển thị tên, nguồn, ngày, số trang, số đơn và tiến độ chỉ mục. Chọn một kết quả thì panel PDF mở trang khớp, hiện các nút chuyển trang khớp. Mã nhận từ PDF có trạng thái đã phát hiện hoặc chưa xác định. Khi chỉ mục đang chạy, kết quả chỉ từ tên và metadata được gắn lý do.

Các thao tác gồm in, Lưu bản sao, đổi tên, mở thư mục, chuyển một hoặc nhiều file vào Thùng rác. Tệp di chuyển bên ngoài hiển thị mất đường dẫn và có nút tìm lại. File hỏng hoặc PDF scan vẫn có mục trong kho, trạng thái phân tích text cho biết vì sao không tìm được mã trang. Khi bật Save As, thao tác bắt đầu từ người dùng để mở hộp thoại Windows. Nguồn lưu tự động có cấu hình riêng. Viewer dùng PDF.js với worker được cấu hình từ tài sản cục bộ. [PDF.js](https://mozilla.github.io/pdf.js/)

### 3.6 Hộp thư và thông báo

- **Danh sách hội thoại.** Bộ lọc sàn, shop, tất cả/chưa đọc/chờ trả lời, tìm kiếm. Mỗi hàng có khách, shop, dấu sàn, đoạn tin cuối, thời gian và số chưa đọc. Cố định lựa chọn khi danh sách thay đổi. Bao phủ tải thêm, mã khách ẩn, hội thoại đã đóng và người mua bị chặn.
- **Hội thoại.** Vùng giữa giữ vị trí khi tải tin cũ. Hỗ trợ soạn, nháp theo hội thoại, trích dẫn, text/ảnh/sticker/sản phẩm/đơn khi được cấp quyền, xem trước tệp và mẫu nhanh. Sau Gửi hiển thị đang gửi, đã gửi, cần đối soát hoặc lỗi. Có mở lại hội thoại, ghim, đánh dấu đã đọc, chặn/bỏ chặn và mở web chat theo quyền.
- **Ngữ cảnh.** Panel bên phải có đơn gần đây, sản phẩm, liên hệ, ảnh trong chat và lịch sử hỏi đáp nếu có. Cập nhật ghi chú đơn xác minh ID shop và đơn. Hỗ trợ collapse độc lập với vùng chat. Các mẫu nhanh có danh sách, sửa, xem trước, lưu và liên kết scope shop hoặc chung.
- **Thông báo.** Chuông trên thanh đầu mở danh sách ngắn. Route đầy đủ hỗ trợ lọc shop, sàn, nhóm chat/đơn/cảnh báo, đã đọc và thời gian. Dưới nhóm đơn phân biệt đơn mới, hỏa tốc, hủy, trả hàng và lịch lấy khi nguồn hỗ trợ. Có đánh dấu từng hoặc tất cả trong phạm vi đã chọn. Nhấn điều hướng tới đúng mục, kể cả khi mất quyền hoặc shop đã bị gỡ. Cài đặt âm thanh chat và đơn riêng theo sàn, kèm nghe thử. Badge biểu thị số chưa đọc trong phạm vi hiện hành.

### 3.7 Tự động hóa và cài đặt

Màn Tự động hóa có bốn loại với chung danh sách shop, trạng thái, lịch lần tới, lỗi gần nhất, editor, xem trước và nhật ký. Phân biệt `Bản nháp`, `Đang bật`, `Tạm dừng`, `Cần cấp lại quyền`, `Đang đối soát`. Nút Chạy thử dùng dữ liệu xem trước. Nút Chạy ngay có xác nhận rõ nếu sẽ gửi lệnh lên sàn.

| Màn soạn | Trường và kiểm tra |
|---|---|
| Trả lời chat | Chu kỳ, rule có thứ tự, danh sách từ khóa, mẫu, fallback và thời gian chờ. Preview cho tin mẫu, biến bắt buộc, trường thay thế, trạng thái nhân viên đã trả lời |
| Đánh giá | Bật đánh giá người mua đủ điều kiện, bật phản hồi theo từng mức sao, nội dung riêng, khoảng cách, preview và trạng thái đã gửi |
| Đẩy sản phẩm | Nhóm được sắp thứ tự, tìm SKU/tên, sản phẩm khả dụng, giới hạn nhóm theo sàn, lần chạy gần nhất, con trỏ nhóm. Dùng 5 mục và khoảng 4 giờ làm dữ liệu tham chiếu khi thử fixture |
| Flash Sale | Chọn slot theo vùng, sản phẩm và biến thể, giá gốc, giá sale, tồn, giới hạn mua, áp dụng hàng loạt và kết quả từng dòng. Fixture cài giới hạn tham chiếu 10 sản phẩm |

Cài đặt chia **Lưu trữ** với đường dẫn và dung lượng, **Kết nối** với quyền từng shop, **Thông báo** với loại và âm thanh, **In** với Save As và thư mục, **Windows** với khởi động cùng máy, **Cập nhật** với kênh và trạng thái, **Hỗ trợ** với xuất log đã lọc và phiên bản. Tối ưu mạng dạng ưu tiên IPv4 và chặn tài nguyên nền được bật riêng khi kiểm thử tương thích. Thay đường dẫn lưu dùng hộp chọn và báo có thể ghi. Lưu cấu hình bằng cập nhật nguyên tử, sau đó hiển thị tùy chọn áp dụng ngay hay sau khởi động lại.

## 4. Dữ liệu, API và cơ chế chạy

### 4.1 Schema SQLite của sản phẩm mới

Dùng `TEXT` cho UUID và ID sàn. Thiết kế đích lưu thời gian UTC, tiền số nguyên theo đơn vị nhỏ nhất, có migration riêng, backup trước khi nâng schema. Bật foreign keys, WAL và busy timeout. DB desktop nằm dưới `%APPDATA%\\WantSeller-Free`; file PDF vẫn ở đường dẫn người dùng chọn. Bảng dưới mô tả schema đích khi có adapter/scheduler đầy đủ, không phải schema hiện đã triển khai.

| Bảng | Trường chính và ràng buộc |
|---|---|
| `shops` | `id PK, platform, region, name, default_url, sort_order, state, created_at, updated_at, archived_at`. Unique tên chuẩn hóa theo sàn/vùng cho các shop còn hoạt động |
| `connections` | `shop_id PK/FK, external_shop_id, gateway_connection_id, status, capabilities_json, expires_at, last_checked_at`. Token desktop dùng kho bí mật hệ điều hành, SQLite lưu tham chiếu |
| `workspace_tabs` | `id PK, shop_id FK, url, label, position, is_active, updated_at`. Mỗi tab chỉ trỏ shop tồn tại, xóa riêng tab không thu hồi site session |
| `settings` | `key PK, value_json, version, updated_at`. Cập nhật optimistic concurrency ở màn cài đặt |
| `orders` | `id PK, shop_id FK, external_order_id, source_status, normalized_status, currency, total_minor, created_at_remote, due_at, version, updated_at_remote, fetched_at`. Unique shop/mã sàn. Index shop/trạng thái/ngày và shop/hạn |
| `order_items` | `id PK, order_id FK, external_item_id, product_id, variant_id, sku, title, qty, unit_price_minor`. Unique order/item |
| `shipments` | `id PK, order_id FK, external_package_id, tracking_code, carrier, method, state, updated_at`. Index tracking chuẩn hóa, khóa package do sàn cấp theo đơn |
| `shipment_batches`, `batch_items` | Batch có ID, người thao tác, loại và thời điểm. Item có batch, đối tượng, job, trạng thái và lý do. Unique batch/đối tượng |
| `notifications` | `id PK, shop_id FK, source_event_key, type, target_type, target_id, payload_json, arrived_at, read_at`. Unique shop/event. Index shop/read_at/arrived_at |
| `conversations`, `messages` | Định danh ngoại unique trong shop hoặc hội thoại. Hội thoại có `unread_count, last_message_id, revision, lifecycle`. Tin có loại, hướng, thời gian, `client_request_id` và trạng thái gửi |
| `chat_drafts`, `quick_replies` | Nháp khóa operator/hội thoại. Mẫu có scope, tên, text, trạng thái và version. Tệp nháp có đường dẫn nội bộ tạm và TTL |
| `product_cache` | `shop_id, external_product_id, external_variant_id, title, sku, stock, price_minor, currency, fetched_at`. Primary key theo ba ID |
| `print_documents` | `id PK, shop_id, platform, path_key, digest, bytes, mtime_ms, page_count, order_count, index_state, indexed_at, file_state`. Unique đường dẫn chuẩn hóa trong thư mục. Bản sao là quan hệ rõ ràng, dùng digest để tái sử dụng kết quả parse |
| `pdf_pages`, `pdf_page_refs` | Primary key tài liệu/số trang. Ref có loại `order` hoặc `tracking`, giá trị gốc đã giảm dữ liệu, giá trị chuẩn hóa, nguồn, độ tin cậy. Index giá trị chuẩn hóa |
| `print_jobs` | `id PK, document_id FK, printer_name, request_id, status, requested_at, result_at`. Unique request. Ghi nhận kết quả Electron nhận được |
| `automation_plans` | `id PK, shop_id FK, type, config_json, version, status, next_due_at, last_run_at, timezone`. Config có schema riêng từng loại. Lưu rule có thứ tự trong config, cập nhật nguyên tử theo version |
| `jobs`, `job_attempts` | Job có shop, loại, tham chiếu, idempotency key, trạng thái, `run_at, lease_owner, lease_until, attempts, last_error_code`. Unique idempotency key. Index trạng thái/run_at. Attempt giữ thời gian, kết quả và correlation ID |
| `sync_checkpoints`, `import_runs` | Checkpoint theo shop/nguồn, cursor và mốc lần thử. Import có fingerprint nguồn, version, kết quả chạy thử và ID map |
| `audit_events`, `schema_migrations` | Audit giữ operator, hành động, đối tượng, mã kết quả, thời gian và correlation ID. Migration lưu version, checksum và thời gian áp dụng |

Ít nhất có một bộ `migration up` cho DB trống, một fixture bản cũ đã phát hành và một đường khôi phục backup. Shop bị gỡ chuyển archived trước để bảo toàn job và audit theo chính sách lưu. Các truy vấn màn hình chỉ liệt kê shop phù hợp với quyền và trạng thái. File ở nguồn hồ sơ và DB bản gốc được mở read-only khi người dùng nhập dữ liệu.

#### Schema hiện có trong 0.1.0

`src/main/database.ts` khởi tạo SQLite `DatabaseSync`, bật `foreign_keys`, `journal_mode=WAL` và `busy_timeout=5000`. Bản 0.1.0 tạo bảng theo `CREATE TABLE IF NOT EXISTS`; `schema_migrations` ghi phiên bản 1 và 2. Tiền đơn lưu dạng số nguyên `VND × 100`; thời gian nhập lưu ISO/SQLite text. Tệp cũ của WantSeller không tự được mở hoặc nhập.

| Bảng | Cột và chỉ mục hiện có |
|---|---|
| `shops` | UUID `id`, `name`, `platform`, `status`, created/updated; unique `(platform,name)` |
| `settings` | `key`, `value_json`, `updated_at`; hiện chưa có UI sửa key |
| `orders` | UUID, shop FK, mã đơn, trạng thái, ngày, số sản phẩm, doanh thu/phí/vốn/vận chuyển cents, mã vận đơn; unique `(shop_id, external_id)` và index shop/date |
| `print_documents` | UUID, shop FK nullable, đường dẫn, tên, kích thước, số trang, mốc index và thời điểm nhập; unique đường dẫn |
| `print_document_pages` | FK tài liệu, số trang và text; khóa chính tài liệu/trang. Text chỉ nằm trong SQLite local |
| `reply_templates` | UUID, title, content, platform và updatedAt |
| `automation_plans` | UUID, kind, name, notes, enabled/nháp và updatedAt; hiện không có scheduler |
| `schema_migrations` | phiên bản và `applied_at` |

Các thao tác ghi đơn theo transaction `BEGIN IMMEDIATE/COMMIT/ROLLBACK`; upsert dùng shop+mã đơn. Bổ sung migration đánh số thực sự trước khi đổi bảng phát hành. Nếu lược đồ thay đổi sau khi đã cài build 0.1.0, cần kiểm tra cột cũ (`PRAGMA table_info`) rồi `ALTER TABLE`; không xóa DB user data.

### 4.2 Gateway, quyền sàn và sync

Gateway có bảng `users`, `workspace_memberships`, `platform_connections`, `webhook_inbox`, `remote_operations` và `remote_event_log`. Gán vai trò `owner`, `operator`, `viewer`. Renderer nhận danh sách quyền từ main, gateway kiểm tra lại quyền và quyền sở hữu shop ở mọi yêu cầu. Bí mật app và khóa mã hóa nằm trong secret store triển khai. Desktop nhận token ứng dụng ngắn hạn, không nhận bí mật app sàn. Mỗi lần kết nối lưu bản quyền đã cấp và thời điểm kiểm tra. Refresh có khóa theo connection để hai yêu cầu song song không xoay token trùng.

| Endpoint sản phẩm | Hành vi |
|---|---|
| `POST /v1/connections`, `GET /v1/connections/:id` | Tạo yêu cầu cấp quyền và xem trạng thái. Callback xác nhận state, xác minh URL callback và hồi đáp đúng tài khoản |
| `GET /v1/shops/:id/capabilities` | Trả theo từng hành động, trạng thái, lý do, thời điểm kiểm tra và liên kết hỗ trợ |
| `GET /v1/shops/:id/orders`, `GET /v1/shops/:id/orders/:orderId` | Danh sách chuẩn hóa, cursor, dữ liệu chi tiết, thời gian lấy và trạng thái phần dữ liệu tài chính |
| `POST /v1/shops/:id/operations`, `GET /v1/operations/:id` | Cùng operation key trả cùng bản ghi. Lưu loại, đối tượng, hash yêu cầu, trạng thái và kết quả từng mục khi có |
| `GET /v1/shops/:id/events?after=...` | Cursor opaque, trả sự kiện theo thứ tự, checkpoint và chỉ báo cần đồng bộ lại. Desktop lấy bù sau khi kết nối lại |
| `POST /v1/webhooks/:platform` | Xác minh chữ ký qua tài liệu chính thức và dedupe, lưu inbox trước khi trả thành công, xử lý nền rồi chuẩn hóa sự kiện |
| `GET /v1/shops/:id/chat/conversations` và `GET /v1/shops/:id/chat/conversations/:id/messages` | Đọc hội thoại và lịch sử qua capability. Mọi thao tác ghi qua endpoint operations |

Mỗi adapter khai báo capability theo `orders.read`, `orders.ship`, `orders.cancel`, `orders.finance`, `documents.fetch`, `chat.read`, `chat.send.text`, `chat.send.image`, `chat.send.sticker`, `chat.send.product`, `chat.send.order`, `chat.manage`, `products.read`, `boost.write`, `flashSale.write`, `rating.write` và `review.reply`. Thêm quyền hẹp cho ghi chú, trạng thái hội thoại hoặc chặn khi sàn cấp riêng. Mỗi capability có `available`, `requiresAuth`, `requiresPermission`, `unsupported` hoặc `unknown` kèm nguồn kiểm chứng.

Khi khởi tạo adapter thật, điền một record cho từng capability gồm sàn, vùng, URL tài liệu chính thức, loại tài khoản, scope, môi trường thử, giới hạn và mẫu request/response đã che bí mật. Thử đọc trước, sau đó thử ghi với tài khoản thử. Kết nối được tính là sẵn sàng theo capability, không đánh dấu toàn bộ adapter sẵn sàng chỉ vì đăng nhập thành công. Nếu hệ thống gốc dùng dữ liệu hoặc giao thức bên trong, bản triển khai dùng đường tích hợp chính thức hoặc thao tác tay qua Seller Center.

### 4.3 Hợp đồng IPC và lỗi

Các nhóm channel dưới đây bắt buộc có schema request, response, kiểm tra nguồn caller và kiểm thử. API renderer expose theo phương thức hoặc domain, không expose hàm gửi channel tùy ý. Sự kiện trả qua listener có hàm unsubscribe. Hộp thoại lưu, mở thư mục, in và Thùng rác do main xử lý theo ID đã kiểm tra. Renderer nhận `documentId` và URL nội bộ có phạm vi, dữ liệu máy cục bộ cần kiểm soát quyền theo cửa sổ.

| Nhóm IPC | Request quan trọng | Response và sự kiện |
|---|---|---|
| `shops:*` | `list`, `create`, `update`, `connect`, `remove`, `openWorkspace` với shop ID, version, trường được phép | Shop, quyền, lần đồng bộ, `shops:changed` |
| `orders:*` | `list(query)`, `getDetail(orderId)`, `previewShipment(orderIds, options)`, `submitShipment(previewId, requestId)`, `cancel(orderId, reason)` | Cursor, `previewId` hạn ngắn, `batchId`, `orders:batchProgress` và lỗi từng item |
| `documents:*` | `list(filters)`, `get(documentId)`, `pickImport()`, `print(documentId, settings)`, `rename`, `saveCopy`, `trash`, `locate` | Metadata, matched pages, trạng thái tệp, `documents:indexProgress` |
| `chat:*` | `listConversations`, `getMessages`, `getContext`, `send`, `markRead`, `changeState`, `saveQuickReply` | Cursor, `clientRequestId`, trạng thái gửi, `chat:messageChanged`, `chat:countsChanged` |
| `automation:*` | `listPlans`, `savePlan`, `validatePlan`, `previewRun`, `enable`, `pause`, `runNow`, `listRuns` | Plan version, kết quả từng rule hoặc item, `automation:runChanged` |
| `notifications:*` | `list`, `countUnread`, `markRead`, `markAllRead`, `clear` với phạm vi rõ ràng | Cursor và `notifications:updated` |
| `settings:*`, `updates:*`, `migration:*` | Lưu cài đặt theo version, kiểm tra/tải/cài bản cập nhật, chọn DB/chạy thử/nhập | Lỗi theo trường, tiến độ từng bước, thông tin cần restart và báo cáo chạy thử |

Trả `{ ok: true, data }` hoặc `{ ok: false, code, message, retryable, correlationId, fieldErrors? }`. Mã tối thiểu `VALIDATION_ERROR`, `AUTH_REQUIRED`, `FORBIDDEN`, `FEATURE_UNAVAILABLE`, `CONFLICT`, `RATE_LIMITED`, `OFFLINE`, `SOURCE_NOT_FOUND`, `FILE_UNAVAILABLE`, `NEEDS_RECONCILIATION`, `INTERNAL`. Request tạo lệnh ghi luôn có request ID và shop, trả ID bản ghi bền để truy vấn lại. ID không được dùng để suy diễn quyền. Giới hạn kích thước chuỗi, attachment, lô và khối lượng PDF ở main. Bản hiện tại nhận CSV tối đa 20.000 dòng; PDF tối đa 50 MiB, 2.000 trang và 10 MB text. Gateway sau này có thể giới hạn shipment batch 100 item. Ghi giới hạn vào cấu hình và đo lại với fixture lớn.

#### IPC hiện tại

Preload expose `window.wantSeller` theo API dưới đây. Handler kiểm tra ID/schema trước khi dùng; chưa có subscription event, OAuth hoặc lệnh ghi lên sàn.

| API preload | Tác động |
|---|---|
| `getInfo`, `controlWindow`, `showDataFolder` | Thông tin build, điều khiển cửa sổ và mở thư mục `%APPDATA%\\WantSeller-Free` |
| `listShops`, `createShop` | Thêm/list shop cục bộ; status mặc định disconnected |
| `listOrders`, `importOrdersCsv`, `exportOrdersCsv` | Chọn CSV bằng dialog, parse ở main, validate tối đa 20.000 dòng và upsert transaction |
| `listPrintDocuments`, `importPrintDocuments`, `removePrintDocument`, `openPrintDocument` | Danh mục PDF; gỡ chỉ xóa metadata, không xóa file người dùng |
| `getPrintPdfData`, `savePrintPdfIndex`, `listIndexedPdfPages` | Đọc PDF theo ID đã đăng ký, ghi và tìm text trang cục bộ |
| `listReplyTemplates`, `saveReplyTemplate`, `deleteReplyTemplate` | CRUD mẫu trả lời local; không gửi chat |
| `listPlans`, `savePlan`, `deletePlan` | CRUD kế hoạch nháp; chưa có scheduler hoặc runner |

### 4.4 Scheduler, dữ liệu offline và tác vụ ghi

- **Nhận job.** Trong transaction, lấy job đến hạn có trạng thái `queued` hoặc `retry_scheduled`, đặt `lease_owner` và `lease_until`. Bắt đầu với lịch quét 1 giây, tối đa 4 job chạy chung và một thao tác ghi trên cùng shop khi cần giữ thứ tự. Giới hạn theo platform/adapter là cấu hình riêng và tôn trọng chỉ dẫn retry do sàn trả.
- **Gửi và đối soát.** Trước khi gọi gateway, ghi attempt và idempotency key. Ví dụ đi đơn khóa theo shop, đơn và hành động. Khi timeout sau gửi, chuyển `needs_reconciliation`, kiểm tra operation hoặc trạng thái sàn trước khi gửi lại. Nếu nguồn trả chắc chắn chưa nhận và lệnh an toàn để thử lại, chuyển `retry_scheduled`. Nếu chưa xác định, hiện yêu cầu xử lý.
- **Phục hồi.** Khởi động lại thu hồi lease hết hạn. Job đã gửi ưu tiên đối soát, job chưa gửi có thể tiếp tục. Tạm dừng shop giữ cấu hình và ngưng cấp lease. Huỷ job đang chạy có trạng thái ngừng chờ hoặc chờ kết quả. Kết thúc chương trình chờ lưu trạng thái và ngưng nhận job mới.
- **Offline.** Orders, PDF và lịch sử có thể đọc từ cache với thời điểm cập nhật. Lệnh đòi xác minh điều kiện sàn lưu ở bản nháp hoặc báo mất mạng. Lịch không gửi bù hàng loạt khi máy vừa thức, từng loại plan có quy tắc còn hạn và kiểm tra lại.
- **Xác định lần chạy.** Chat ưu tiên rule đầu tiên khớp, fallback sau khoảng chờ, tăng độ an toàn bằng kiểm tra tin mới nhất và lịch sử trả lời. Đánh giá có key theo shop/đơn hoặc review/loại. Boost đặt cursor sau khi biết nhóm đã xử lý nhất quán. Flash Sale đối soát slot và nguồn thời gian trước submit, ghi kết quả từng biến thể.
- **Lỗi và đo lường.** Ghi log JSON quay vòng, giữ duration, correlation ID, loại tác vụ và mã lỗi. Đo độ trễ sync, số lease quá hạn, lệnh cần đối soát, kết quả in, và gateway rate-limit. Tách thông tin chẩn đoán khỏi nội dung chat hoặc dữ liệu khách hàng.

### 4.5 Tài liệu PDF và file Windows

1. `previewShipment` ghi tập đơn/kiện, các phiên bản dữ liệu và các dòng không đủ điều kiện. Sau submit, lấy tài liệu từ adapter được cấp quyền hoặc người dùng nhập PDF. Tách service đồng bộ đơn, service phiếu và thao tác máy in.
2. Main lựa chọn đường dẫn, sử dụng tên an toàn, ghi temp trong thư mục đích rồi đổi tên. Kiểm tra PDF, giới hạn dung lượng, tính SHA-256, ghi metadata. Không dùng tên hoặc đường dẫn từ sàn làm đường dẫn tuyệt đối. Lưu bản sao và đổi tên có xử lý trùng, thất bại một phần và tệp bị xóa ngoài app.
3. Lập chỉ mục qua utility process. Parse từng PDF, lấy text/bounds theo trang, tìm mã được biết từ metadata trước, sau đó nhận diện mã theo mẫu được test. Chuẩn hóa mã bằng quy tắc từng loại. Ghép baseline theo shop và sàn nếu có rồi lưu kết quả từng trang. Khi tệp thay đổi kích thước, mốc sửa hoặc hash, huỷ kết quả cũ và lập lại. Portal tìm kiếm CSV hoặc OCR là phần mở rộng sau khi mẫu test chứng minh cần.
4. Viewer chỉ đọc tài liệu đã đăng ký. `print` mở bề mặt in riêng, kiểm tra trạng thái sẵn sàng rồi gửi lệnh. Ghi kết quả nhận vào hàng đợi máy in. Trạng thái in vật lý chỉ hiển thị nếu có nguồn xác nhận. Trong kho, Thùng rác dùng API hệ điều hành, cập nhật tệp và chỉ mục sau thành công.
5. E2E dùng mẫu nhiều trang có hai hãng vận chuyển, một bản scan, một file lỗi và một file thay đổi khi đang index. Kết quả tra mã phải nêu được tài liệu, số trang hoặc lý do chưa xác định. Mẫu Unicode, thư mục hết dung lượng, hủy chọn máy in, tệp mất và batch xóa lỗi một phần đều có thông báo và khả năng khôi phục.

Trong 0.1.0, người dùng chọn một hoặc nhiều PDF trong hộp thoại Windows; app chỉ lưu metadata/đường dẫn, không di chuyển file. Khi bấm lập chỉ mục, main đọc file từ ID tài liệu đã đăng ký, giới hạn 50 MiB, renderer dùng PDF.js 6.5 để trích text đến 2.000 trang/10 MB và lưu trang vào SQLite. Viewer nạp bytes PDF qua IPC, dựng một trang canvas tại một thời điểm; nút mở ngoài dùng app PDF mặc định. Tìm kiếm văn bản là substring, trả tên file/trang/excerpt. Scan ảnh không OCR. Hash, kiểm tra file di chuyển, tự động theo dõi thư mục, batch in, lưu bản sao và trash vẫn là hạng mục sau.

### 4.6 Nhập dữ liệu từ WantSeller schema 12

Nguồn mẫu quan sát được có `meta`, `shops`, `tabs`, `tabs_meta`, `notifications`, `order_stats`, `boost_plans`, `flash_sale_plans`, `rating_plans`, `chatreply_plans`. Phiên bản schema lưu ở `meta.schema_version`, `PRAGMA user_version` trong mẫu mặc định là 0. Có thể có nhiều file `app.db` cùng version ở hồ sơ và các thư mục thiết lập. Người vận hành chọn một nguồn và thấy thông tin schema, thời điểm file, số bản ghi phù hợp và lỗi trước khi nhập.

| Nguồn | Chuyển đổi |
|---|---|
| Shop và tab | Map ID cũ → ID mới, giữ tên/sàn/thứ tự và URL đã kiểm tra. Trùng sàn/vùng/tên thì hỏi chọn liên kết hoặc đổi tên. Tab mồ côi ghi vào báo cáo |
| Kết nối | Kích hoạt cấp quyền mới theo shop. Các trường mật khẩu, cookie, token, OTP và dữ liệu phiên của bản cũ không dùng làm đầu vào kết nối |
| Thông báo và bộ đếm | Nhập khi người vận hành chọn. Map shop và trạng thái đã đọc, đổi epoch giây sang ms theo schema, ghi lại thời điểm nguồn. Bộ đếm là cache, hết hạn sau lượt đồng bộ đầu tiên |
| Kế hoạch | Map loại và cấu hình JSON có schema validation. Giữ thứ tự nhóm/rule. Giữ các mốc cũ làm tham chiếu. Đặt bản nháp và yêu cầu người vận hành kiểm tra quyền, template, kho và slot trước khi bật |
| Tài liệu | Chọn thư mục PDF qua hộp thoại, đọc metadata và đưa vào chỉ mục đích. Trùng digest/path xử lý theo chính sách chọn trước |
| Cài đặt | Chuyển tùy chọn âm thanh và khởi động nếu nhận diện được. Các đường dẫn cần xác nhận quyền ghi và tồn tại. Xem trước thay đổi trước khi áp dụng |

Import lưu dấu nhận diện nguồn, record mapping và job ID. Thực hiện dry-run, backup DB mới, rồi commit trong transaction theo nhóm dữ liệu. Thất bại giữ báo cáo và cung cấp rollback bản nhập. Chạy lặp cùng nguồn không tạo shop, tab và thông báo trùng. Kiểm thử DB bị khóa, schema lạ, JSON hỏng, âm thanh thiếu asset, hai DB cùng version và nhiều shop trùng tên.

## 5. Trình tự triển khai đến mức có thể giao việc

Mỗi đợt phải có demo chạy bằng fixture, migration nếu schema đổi, test lỗi tối thiểu và cập nhật ma trận capability. Các hành động đọc, ghi và xóa được kiểm thử tách riêng. Dashboard và thống kê triển khai trên dữ liệu đồng bộ, có trạng thái trống khi kết nối chưa cấp quyền.

| Đợt | Công việc theo thứ tự | Bàn giao mục tiêu | Trạng thái 0.1.0 |
|---|---|---|---|
| 0. Bộ khung | Shell React/Electron → theme → preload sandbox → SQLite → scripts build | App chạy, build NSIS, dữ liệu riêng user profile | Shell, IPC và build đã có; tạo bộ cài/phát hành còn chờ |
| 1. Dữ liệu và Shop | Shop CRUD → database → nhập đơn CSV → tổng hợp lãi → quản lý mẫu/kế hoạch | Dữ liệu sống qua restart; CSV nhiều shop tách theo shop ID | Shop, đơn CSV, plan và mẫu đã có; chưa có sửa/gỡ shop |
| 2. Gateway và đồng bộ | OAuth/API chính thức → adapter mỗi sàn → capability → webhooks/checkpoints | Token hết hạn, mất mạng, dedupe và quyền đúng shop được xử lý | Chưa triển khai; chờ tạo app/developer access và sandbox từng sàn |
| 3. Đơn/giao vận | Đồng bộ đọc → detail → xử lý batch → preview/submit/reconcile → hủy/tài chính theo quyền | Không gửi trùng; lỗi một phần và điều kiện vận hành rõ | Chưa kết nối API; danh sách CSV và báo cáo lãi chạy offline |
| 4. Phiếu in | Import → chỉ mục PDF → viewer → mã đơn/tracking page refs → print/copy/trash | Tìm trang trong PDF nhiều trang và mở trang chính xác | Danh mục, index text theo trang, search substring và preview đã có; OCR/print batch chưa có |
| 5. Thông báo/Tổng quan | Dedupe → unread → deep link → KPI theo nguồn/mốc đồng bộ | Đếm unread và shop scope khớp sự kiện | Chưa có notification store; KPI đã đếm CSV/PDF, unread vẫn là placeholder |
| 6. Chat Đa Sàn | OAuth reader → inbox → messages → compose → capability → mẫu | Gửi có trạng thái và replay không nhân đôi | Mẫu/copy đã có; inbox/gửi chờ API được duyệt |
| 7. Tự động hóa | Rule editor → preview → scheduler → log → từng API action | Chạy thử và idempotent; có pause/resume và giải thích lỗi | Lưu checklist nháp đã có; không có scheduler/runner |
| 8. Nhập dữ liệu cũ | Schema probe → dry-run → mappings → import nhóm → báo cáo | Không nhập bí mật; chạy lại không nhân bản; nguồn không đổi | Chưa có wizard; SQLite cũ đã phân tích read-only, chưa đọc nội dung nhạy cảm |
| 9. Phát hành miễn phí | README/giấy phép/notice → installer → checksum → CI → GitHub public | Windows sạch cài/nâng cấp và giữ dữ liệu; không HWID gate | Đang chuẩn bị; cần hoàn thiện installer, Git repo, namespace GitHub và quyền publish |

### 5.1 Cách làm một lát cắt đầu tiên

Lát cắt đầu tiên nên là **Shop → Đơn Shopee → PDF fixture**, có giao diện, IPC, SQLite và test đi cùng ngay từ đầu:

1. Seed hai shop Shopee và một shop TikTok. Một shop Shopee có ba đơn, shop còn lại có một đơn trùng mã ngoại để kiểm tra khóa theo shop. Seed dữ liệu trong temp và không để mode fixture ghi vào DB người dùng.
2. Viết schema `OrderListQuery`, `OrderListResult` và `OrderDetail` trong contracts. Thêm query SQLite phân trang và filter shop. IPC nhận filter và trả giá trị đã normalize. Viết unit cho filter và integration cho hai shop có mã đơn giống nhau.
3. Tạo route Shop và đơn, lọc shop từ URL, mở drawer khi chọn dòng. Tạo checkbox lựa chọn theo ID. Hiện thông tin thiết yếu trên bảng, giá và khách trong panel. Kiểm thử route khi ID không tồn tại hoặc kết nối hết quyền.
4. Seed một PDF hai trang và lưu một record tài liệu. Route Kho phiếu tải metadata và preview page 1. Mã thứ hai có ở page 2, indexer trả đúng trang. E2E bắt đầu từ shop, lọc đơn, mở phiếu, tra mã và mở đúng trang.
5. Khi lát cắt đạt, mở rộng thao tác hàng loạt, queue, trạng thái lỗi và dùng adapter gateway thật. Bổ sung cùng hợp đồng fixture cho lỗi rate limit, mạng mất và quyền bị thu hồi.

### 5.2 Bộ fixture tối thiểu

| Bộ dữ liệu | Trường hợp bắt buộc |
|---|---|
| Shops | Hai shop cùng sàn, một shop chưa kết nối, một token hết hạn, một shop bị thu hồi quyền, một shop có PDF Lazada |
| Orders | Mã ngoài trùng giữa shop, một đơn nhiều kiện, sắp hết hạn, đặt trước, hỏa tốc, ghi chú, chỉ một SKU, nhiều SKU, đơn đổi trạng thái trong lúc preview |
| Ship batch | Thành công, không đủ điều kiện, lỗi có thể retry, thất bại sau khi sàn đã nhận, lỗi vĩnh viễn. Có hai lượt click cùng request ID |
| PDF | Một đơn, nhiều đơn/mã trên các trang, mã trùng khác sàn, scan ảnh, file hỏng, Unicode, tệp đã đổi đường dẫn và tệp biến đổi khi parse |
| Chat | Hai sàn, hai shop có khách trùng tên, hội thoại khóa, chưa đọc, gửi ảnh lỗi, tin đến sau reconnect, conversation closure đang thay đổi và session hết quyền |
| Automation | Rule trùng, fallback bằng 0, template thiếu biến, nhân viên đã trả lời, review đã được trả lời, sản phẩm mất, slot hết hạn và biến thể giảm tồn |
| Legacy schema | DB v12 hợp lệ, trùng định danh, dữ liệu mồ côi, epoch giây, JSON sai, hai nguồn tồn tại song song, schema chưa hỗ trợ |

## 6. Nghiệm thu, phát hành và vận hành

### 6.1 Test chức năng và điều kiện lỗi

| ID | Kịch bản thực hiện | Kết quả cần thấy |
|---|---|---|
| T01 | Cài sạch, thêm hai shop, mở tab mỗi shop, restart, xóa phiên một shop | Tab khôi phục, phiên shop còn lại hoạt động. Log tránh lộ dữ liệu phiên |
| T02 | Lọc theo shop và giờ, chọn 5 đơn, đổi trạng thái một đơn trước khi submit, làm mất mạng tại một request | Cảnh báo đơn đã đổi, chỉ gửi phần hợp lệ. Lệnh chưa rõ được đối soát khi kết nối lại |
| T03 | Mở kho, nhập PDF nhiều trang, tìm mã giữa file, đổi tên, lưu bản sao rồi đưa bản sao vào Thùng rác | Đúng trang khớp, tài liệu gốc còn, dữ liệu chỉ mục khớp tình trạng file |
| T04 | Đưa hai shop vào Inbox, phát sự kiện trùng và lệch thứ tự, mở hội thoại và xóa kết nối một shop | Unread chính xác, trạng thái đọc bền, shop còn lại dùng bình thường |
| T05 | Gửi text và ảnh qua tài khoản thử, gây lỗi sau submit rồi mở app lại | Thấy trạng thái gửi hoặc đối soát. Cùng request không tạo tin trùng |
| T06 | Tạo rule chat/đánh giá, Flash Sale hai biến thể, tạm dừng, bật lại, thử slot hết hạn và hết kho | Hiện kết quả từng rule/mục. Không chạy mục hết hạn, còn lịch và báo cáo sau restart |
| T07 | Nhập DB cũ, nhập lại, thử JSON lỗi và hủy sau dry-run | Nguồn được giữ nguyên. Không nhân bản dữ liệu. Báo rõ mục lỗi và plan chờ xác nhận |
| T08 | Bật thông báo riêng từng sàn, giảm cửa sổ, thử âm thanh và thao tác khi app offline | Đúng nguồn, không phát hai lần cho một event, có mốc đồng bộ và trạng thái offline |
| T09 | Cài bản mới qua gói ký và kiểm tra rollback thử trên bản sao | Kiểm tra chữ ký, xác nhận lịch đang chạy và bảo toàn DB. Rollback phục hồi đúng schema |
| T10 | Thử IPC sai kiểu, ID shop của tài khoản khác, URL ngoài allowlist, đường dẫn ngoài phạm vi và attachment quá lớn | Bị từ chối có lỗi phù hợp, không thay đổi dữ liệu. Log chỉ ghi metadata lỗi |

Ngoài E2E, Vitest kiểm thử reducer job, tính giá, validate slot, rule matching, chuẩn hóa PDF ref và chuyển schema. Test tích hợp xác minh transaction, nhiều worker tranh lease, update khi job đang chạy, timeout, mutation gateway lặp và dữ liệu lỗi. Dùng test fixture tài khoản giả cho PR. Tài khoản staging được dùng trong pilot theo quyền được cấp.

### 6.2 Mốc hiệu năng và khả năng sử dụng

Mục tiêu ban đầu trên máy Windows thử có SSD và 8 GB RAM: shell fixture mở dưới 5 giây ở p95, phân trang đơn từ local cache dưới 500 ms ở p95 với 10.000 đơn, tìm chỉ mục PDF sẵn có dưới 700 ms ở p95 với 5.000 tệp. Ghi cấu hình máy, kích cỡ fixture và số lần đo khi công bố kết quả. Indexer nền hiển thị tiến độ và cho hủy, route vẫn tương tác trong lúc index. Các thao tác gọi sàn đo riêng phần mạng và thời gian xử lý. Tính đáp ứng khi zoom 150%, focus có thể nhìn thấy, bàn phím làm được luồng chính, bố cục bảng không che nút xác nhận.

### 6.3 Điều kiện phát hành

- **Chức năng.** T01–T10 qua trên fixture. Các thao tác sàn được công bố có bằng chứng sandbox hoặc pilot kèm vai trò, vùng và quyền. Các capability chưa có quyền hiển thị đúng fallback.
- **Dữ liệu.** Cài mới, migrate, backup, restore và import chạy thành công. Tên tệp Unicode, đường dẫn dấu cách, thư mục hết dung lượng và tệp bị khóa có test. Mỗi gói cài dùng đường dẫn dữ liệu riêng khỏi bản tham chiếu.
- **Ký và cập nhật.** CI build Windows x64 có ký, sinh checksum, kiểm tra cài nâng cấp từ bản đã phát hành, phát hành staging trước stable. Chỉ cài update sau khi người dùng chọn hoặc đến chính sách đã đặt. Lúc restart, job ghi phải được lưu và lease hiện hành được xử lý.
- **Phục hồi.** Rollback bản app chỉ thực hiện khi schema cũ đọc được hoặc có snapshot phù hợp. Giao diện vận hành có khả năng tạm dừng thao tác ghi theo sàn, giữ cache đọc và theo dõi các job cần đối soát.
- **Bàn giao.** Có bộ cài, diff migration, danh sách khả năng của từng sàn, dữ liệu mẫu, hướng dẫn thiết lập gateway, báo cáo smoke, hướng dẫn hỗ trợ và quy trình khôi phục.

Pilot bắt đầu một shop Shopee đọc đơn và PDF, sau đó nhiều shop và quyền ghi có giám sát. Mở tiếp Inbox Shopee/TikTok và từng loại tự động hóa theo kết quả pilot. Theo dõi độ trễ đồng bộ, số job không rõ kết quả, hành động ghi lặp, lỗi file và số lượt phải kết nối lại. Tạm dừng mở rộng khi lỗi dữ liệu hoặc tác vụ ghi chưa đối soát vượt ngưỡng pilot. Ghi người chịu trách nhiệm và hướng xử lý theo từng mã lỗi.

## 7. Bằng chứng và các quyết định còn mở

| Bằng chứng từ bản tham chiếu | Kết luận dùng cho build |
|---|---|
| Bộ cài `WantSeller-1.4.2.exe` có SHA-256 `d5fce1fd5c3d0832ab296e80f0ae0692e0dc4d326d8f99ac5b173814d0fd8358` | Mốc so sánh bộ cài ban đầu, Electron và ASAR |
| Bản chạy `%LOCALAPPDATA%/Programs/WantSeller/WantSeller.exe` là 1.5.0. `resources/app.asar` có SHA-256 `62c972997666a02eb9a627184604688c71352556213fdabdd8a9fab5b0a6421a` | Nguồn giao diện/bề mặt chức năng hiện tại. Kiểm kê REA cho 2.607 tệp và 577 thư mục. So sánh ngoài `node_modules` thấy 24 mục thêm, 110 mục đổi |
| `src/public/index.html`, `src/preload.js`, `src/main/webview-manager.jsc` | Shell đa shop, quản lý tab/web, thông báo, cài đặt, bật cửa sổ nghiệp vụ |
| `src/public/order-manager.html`, `src/preload-order.js`, `src/domains/shopee/shopee-order-service.jsc` | Đơn Shopee, danh sách, chi tiết, lô đi đơn, giao vận, in, hủy/tài chính có bề mặt gọi. Đóng hàng và Gửi hàng được ghi đang phát triển |
| `src/public/print-manager.html`, `src/preload-print.js`, `src/main/pdf-order-indexer.jsc`, `src/main/print-capture/platforms/` | Kho file in, xem theo trang, tìm mã, tiến độ lập chỉ mục, bộ lọc và mô-đun tài liệu ba sàn |
| `src/public/shopee-chat.html`, `src/preload-shopee-chat.js`, `src/main/ipc-shopee-chat.jsc`, các module chat center Shopee/TikTok | Chat Đa Sàn Beta, danh sách/sự kiện, thao tác gửi/chặn/ghim và panel ngữ cảnh. Phải xác minh quyền từng thao tác |
| `src/public/{boost,flashsale,rating,chatreply}-manager.html` và các worker tương ứng | Editor, kế hoạch, mẫu, lịch, log và tính năng tự động hóa theo shop |
| `%APPDATA%/wantseller/app.db` và DB ở thư mục cấu hình | Đã đọc schema 12 ở chế độ read-only, 10 bảng. Lưu lịch, cấu hình, số đếm và shop. Schema mẫu không có bảng từng đơn hoặc bản tin chat |
| `src/main/network-optimizer.jsc`, `src/main/ipc-autoupdate.jsc`, `app-update.yml` | Có bề mặt tùy chọn IPv4 và cập nhật. Hành vi phát hành, backend cấp phép và quyền API cần tài liệu hoặc môi trường thử |

Mốc hiện tại là alpha có shell, shop cục bộ, CSV đơn hàng và lãi ước tính, kho PDF có tìm kiếm nội dung và viewer, mẫu phản hồi, kế hoạch tự động hóa nháp. `npm run typecheck`, `npm run build`, `npm audit` (0 lỗ hổng), smoke PDF nhập → lập chỉ mục → tìm mã → xem trước và đóng gói NSIS x64 đã qua; checksum của installer nằm trong release notes. Repo Git local đã khởi tạo và stage. Chưa có Authenticode, cài sạch hoặc E2E tự động. GitHub owner/repository và xác thực còn chờ kết nối. API marketplace, Inbox, scheduler chạy thật, OCR, nhập DB legacy và updater chưa hoàn tất. Không mô tả alpha này như bản thay thế đầy đủ tính năng production của WantSeller 1.5.0.
