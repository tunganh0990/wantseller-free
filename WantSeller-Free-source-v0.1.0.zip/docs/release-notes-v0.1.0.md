# WantSeller Free 0.1.0 Alpha

WantSeller Free is a local-first Windows desktop rebuild for seller workflows. This alpha uses the WantSeller reference interface and assets under the permissions confirmed by the project owner. It is an independent community build, not an official vendor release.

## Included

- Multi-shop labels and local shop records.
- Per-shop revenue/profit overview, seven-day sales chart, and a reminder to review orders with zero recorded expenses.
- CSV order import/export, search, status filters, and estimated profit from the values in the CSV.
- Local PDF catalog, per-page text indexing, search by order/tracking code, and in-app preview.
- Reusable reply templates for manual copy/paste.
- Draft checklists for Boost, Flash Sale, review, and reply workflows.
- Separate local data under `%APPDATA%\WantSeller-Free`; no HWID gate, license server, platform session cookies, or telemetry endpoint in this build.

## Known limitations

This release does not connect to Shopee, TikTok Shop, or Lazada. It has no live order sync, chat inbox/send, marketplace actions, background automation runner, or OCR for scanned PDFs. See the README and implementation plan for current scope and future work.

## Windows x64 installer

- File: `WantSeller Free Setup 0.1.0.exe`
- Size: 142,693,549 bytes
- SHA-256: `BA348573281D4F03EF955E54066357200EB43F16B56EF6B3FB50637058D04403`

The installer is not Authenticode-signed. Build the app yourself from the source using the commands in `README.md` if you prefer.

## Licenses

The new source code is MIT-licensed. WantSeller reference assets and marketplace marks are excluded from that license and retain their separate notices. Review `LICENSE` and `THIRD_PARTY_NOTICES.md` before reuse.
