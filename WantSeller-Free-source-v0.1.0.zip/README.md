# WantSeller Free

> **Ứng dụng Windows miễn phí để quản lý dữ liệu bán hàng đa shop.** Dự án đang ở giai đoạn alpha; phần nhập/xuất và quản lý dữ liệu chạy offline, tích hợp Shopee/TikTok Shop/Lazada chưa được bật.

WantSeller Free tái dựng giao diện và các module của WantSeller 1.5.0 theo quyền sao chép, sửa đổi và phát hành công khai đã được chủ dự án xác nhận. Bản mới không dùng mã cấp phép, HWID, cookie hay dịch vụ xác thực của ứng dụng cũ.

## Tính năng hiện có

- **Quản lý shop:** lưu tên và nền tảng shop trên máy, tách dữ liệu theo shop.
- **Đơn hàng:** nhập CSV UTF-8, tìm theo mã đơn/vận đơn, lọc trạng thái, cập nhật đơn đã nhập và xuất lại CSV.
- **Tổng quan nâng cao:** doanh thu, lãi ước tính và biểu đồ 7 ngày theo shop; nhắc kiểm tra đơn đang ghi nhận tổng chi phí bằng 0.
- **Tổng hợp tài chính:** ước tính lãi bằng doanh thu trừ phí sàn, giá vốn và vận chuyển; kết quả phụ thuộc vào dữ liệu CSV.
- **Kho phiếu in:** thêm PDF vào danh mục mà không di chuyển file, xem trước trong ứng dụng, lập chỉ mục text theo trang và tìm mã đơn/vận đơn.
- **Mẫu phản hồi:** lưu mẫu theo nền tảng rồi sao chép để dán thủ công vào Seller Center.
- **Kế hoạch tự động hóa:** soạn checklist cho Boost, Flash Sale, đánh giá và trả lời chat. Kế hoạch chỉ lưu nháp, chưa tự chạy.
- **Không có HWID gate:** không cần mã kích hoạt hoặc xác nhận với máy chủ quản trị.

## Giới hạn hiện tại

- Chưa đăng nhập hoặc đồng bộ trực tiếp với nền tảng. Kết nối API chỉ được bổ sung qua OAuth/API chính thức khi có quyền ứng dụng và môi trường phù hợp.
- Chưa có inbox chat, gửi tin, thao tác vận đơn, batch xử lý đơn, scheduler hoặc thông báo từ sàn.
- PDF chỉ lập chỉ mục lớp văn bản; file scan ảnh chưa có OCR. Giới hạn hiện tại là 50 MiB, 2.000 trang và 10 MB text mỗi file.
- Dữ liệu của bản WantSeller gốc không tự được mở hoặc nhập. App dùng DB riêng tại `%APPDATA%\WantSeller-Free`.

## Nhập đơn CSV

Chọn shop, vào **Xử Lý Đơn Hàng → Nhập CSV**, rồi chọn tệp xuất từ sàn. Cột có thể dùng tiếng Việt hoặc tiếng Anh:

| Trường | Header thường dùng |
|---|---|
| Mã đơn | `order_id`, `ma_don_hang`, `order_number` |
| Trạng thái | `status`, `trang_thai` |
| Ngày đặt | `order_date`, `ngay_dat`, `created_at` |
| Số sản phẩm | `item_count`, `so_luong`, `quantity` |
| Tổng tiền VND | `total`, `tong_tien`, `order_value` |
| Phí sàn VND | `platform_fee`, `phi_san`, `marketplace_fee` |
| Giá vốn VND | `cost`, `gia_von`, `product_cost` |
| Vận chuyển VND | `shipping`, `phi_van_chuyen`, `shipping_fee` |
| Mã vận đơn | `tracking_code`, `ma_van_don`, `waybill` |

Chỉ bắt buộc có mã đơn. Mỗi lần nhập tối đa 20.000 dòng. Đơn có cùng mã trong cùng shop được cập nhật; shop khác có thể có cùng mã đơn. App không đọc tên, địa chỉ hoặc số điện thoại khách hàng từ CSV.

Tải mẫu header tại [`examples/orders-template.csv`](examples/orders-template.csv).

## Phát triển

Yêu cầu Node.js 26.13.1 (xem `.node-version`) và npm trên Windows.

```powershell
npm.cmd ci
npm.cmd run dev
npm.cmd run typecheck
npm.cmd run build
npm.cmd run dist:win
```

Muốn cô lập hồ sơ khi phát triển, đặt biến `$env:WANTSELLER_DATA_DIR` trước khi chạy `npm.cmd run dev`; biến này chỉ được đọc ở chế độ phát triển.

Bộ cài NSIS x64 được tạo trong `release/`. Dữ liệu SQLite nằm trong hồ sơ người dùng `%APPDATA%\WantSeller-Free`; cài lại app không xóa DB.

Xem [ghi chú phát hành 0.1.0 Alpha](docs/release-notes-v0.1.0.md) để biết giới hạn và checksum của installer.

## Kiến trúc

- `src/main/index.ts`: Electron main, Zod validation, SQLite IPC, dialog CSV/PDF.
- `src/main/database.ts`: schema SQLite và repository cho shop/đơn/PDF/mẫu/kế hoạch.
- `src/preload/index.ts`: bridge giới hạn `window.wantSeller`.
- `src/renderer/src/App.tsx`: shell, điều hướng và quản lý shop.
- `src/renderer/src/Features.tsx`: các module đơn hàng, PDF, mẫu chat, kế hoạch và cài đặt.
- `src/renderer/assets/reference/`: ảnh/logo và stylesheet tham chiếu được phân phối theo quyền riêng của dự án; chúng không được cấp phép lại theo MIT.

Renderer chạy với `nodeIntegration: false`, `contextIsolation: true` và sandbox. Không có endpoint telemetry hoặc server quản trị trong source hiện tại.

Đọc [đặc tả build và lộ trình đầy đủ](docs/implementation-plan.md) để xem định hướng UI, kiến trúc, dữ liệu, các luồng chưa tích hợp và điều kiện phát hành.

## Lộ trình

1. Hoàn thiện bộ cài, nội dung trợ giúp, nhập CSV và PDF trên Windows sạch.
2. Thêm sửa/gỡ shop, dashboard theo shop và thông báo cục bộ.
3. Hoàn thiện viewer/in PDF, tìm kiếm mã theo định dạng sàn và OCR tùy chọn.
4. Xin/thiết lập app developer chính thức cho từng sàn trước khi thêm đăng nhập, đọc đơn hoặc chat.
5. Chỉ bật thao tác ghi và tự động hóa sau khi có quyền, sandbox, đối soát idempotent và xác nhận người vận hành.

## Giấy phép và tài sản tham chiếu

Mã nguồn mới được cấp phép theo MIT, trừ các tệp được liệt kê trong [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md). Tên WantSeller, icon/logo sàn và CSS/ảnh tham chiếu được sử dụng theo quyền mà chủ dự án xác nhận; các tệp đó không thuộc giấy phép MIT của mã mới. PDF.js được phát hành theo Apache-2.0. Xem [LICENSE](LICENSE) và thông báo trước khi tái sử dụng tài sản.

---

**English:** A free Windows desktop rebuild for local multi-shop workflows. CSV order management, profit estimates, PDF text indexing, reply templates, and draft automations are available offline. Official marketplace API integrations are not enabled yet.
