import { contextBridge, ipcRenderer } from "electron";
import type { AutomationPlan, Order, Platform, PrintDocument, ReplyTemplate, Shop } from "../main/database";

type PlanKind = AutomationPlan["kind"];

const api = {
  getInfo: (): Promise<{ name: string; version: string; mode: "free"; dataPath: string }> =>
    ipcRenderer.invoke("app:get-info"),
  listShops: (): Promise<Shop[]> => ipcRenderer.invoke("shops:list"),
  createShop: (input: { name: string; platform: Platform }): Promise<Shop> =>
    ipcRenderer.invoke("shops:create", input),
  listOrders: (shopId?: string): Promise<Order[]> => ipcRenderer.invoke("orders:list", shopId),
  importOrdersCsv: (shopId: string): Promise<{ imported: number; updated: number; canceled?: boolean }> =>
    ipcRenderer.invoke("orders:import-csv", shopId),
  exportOrdersCsv: (shopId?: string): Promise<{ canceled: boolean; count: number }> =>
    ipcRenderer.invoke("orders:export-csv", shopId),
  listPrintDocuments: (shopId?: string): Promise<PrintDocument[]> => ipcRenderer.invoke("documents:list", shopId),
  listIndexedPdfPages: (): Promise<Array<{ documentId: string; pageNumber: number; text: string; fileName: string }>> => ipcRenderer.invoke("documents:indexed-pages"),
  getPrintPdfData: (id: string): Promise<Uint8Array> => ipcRenderer.invoke("documents:pdf-data", id),
  savePrintPdfIndex: (input: { id: string; pages: Array<{ pageNumber: number; text: string }> }): Promise<void> => ipcRenderer.invoke("documents:save-index", input),
  importPrintDocuments: (shopId?: string): Promise<{ canceled: boolean; count: number }> =>
    ipcRenderer.invoke("documents:import", shopId),
  openPrintDocument: (id: string): Promise<string> => ipcRenderer.invoke("documents:open", id),
  removePrintDocument: (id: string): Promise<void> => ipcRenderer.invoke("documents:remove", id),
  listReplyTemplates: (): Promise<ReplyTemplate[]> => ipcRenderer.invoke("templates:list"),
  saveReplyTemplate: (input: { id?: string; title: string; content: string; platform: Platform | "all" }): Promise<ReplyTemplate> =>
    ipcRenderer.invoke("templates:save", input),
  deleteReplyTemplate: (id: string): Promise<void> => ipcRenderer.invoke("templates:delete", id),
  listPlans: (kind: PlanKind): Promise<AutomationPlan[]> => ipcRenderer.invoke("plans:list", kind),
  savePlan: (input: { id?: string; kind: PlanKind; name: string; notes?: string; enabled?: boolean }): Promise<AutomationPlan> =>
    ipcRenderer.invoke("plans:save", input),
  deletePlan: (id: string): Promise<void> => ipcRenderer.invoke("plans:delete", id),
  showDataFolder: (): Promise<string> => ipcRenderer.invoke("app:show-data-folder"),
  controlWindow: (control: "minimize" | "toggle-maximize" | "close"): Promise<void> =>
    ipcRenderer.invoke("window:control", control),
};

contextBridge.exposeInMainWorld("wantSeller", api);
