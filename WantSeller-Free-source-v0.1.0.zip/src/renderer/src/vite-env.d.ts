/// <reference types="vite/client" />

declare global {
  interface Window {
    wantSeller: {
      getInfo(): Promise<{ name: string; version: string; mode: "free"; dataPath: string }>;
      listShops(): Promise<Array<{
        id: string;
        name: string;
        platform: "shopee-vn" | "tiktok-vn" | "lazada-vn";
        status: "disconnected" | "connected" | "needs-auth";
        createdAt: string;
      }>>;
      createShop(input: {
        name: string;
        platform: "shopee-vn" | "tiktok-vn" | "lazada-vn";
      }): Promise<{
        id: string;
        name: string;
        platform: "shopee-vn" | "tiktok-vn" | "lazada-vn";
        status: "disconnected" | "connected" | "needs-auth";
        createdAt: string;
      }>;
      listOrders(shopId?: string): Promise<Array<{
        id: string; shopId: string; externalId: string; status: string; orderDate: string | null;
        itemCount: number; totalCents: number; platformFeeCents: number; costCents: number;
        shippingCents: number; trackingCode: string; importedAt: string;
      }>>;
      importOrdersCsv(shopId: string): Promise<{ imported: number; updated: number; canceled?: boolean }>;
      exportOrdersCsv(shopId?: string): Promise<{ canceled: boolean; count: number }>;
      listPrintDocuments(shopId?: string): Promise<Array<{
        id: string; shopId: string | null; filePath: string; fileName: string; sizeBytes: number; pageCount: number; indexedAt: string | null; importedAt: string;
      }>>;
      listIndexedPdfPages(): Promise<Array<{ documentId: string; pageNumber: number; text: string; fileName: string }>>;
      getPrintPdfData(id: string): Promise<Uint8Array>;
      savePrintPdfIndex(input: { id: string; pages: Array<{ pageNumber: number; text: string }> }): Promise<void>;
      importPrintDocuments(shopId?: string): Promise<{ canceled: boolean; count: number }>;
      openPrintDocument(id: string): Promise<string>;
      removePrintDocument(id: string): Promise<void>;
      listReplyTemplates(): Promise<Array<{ id: string; title: string; content: string; platform: "shopee-vn" | "tiktok-vn" | "lazada-vn" | "all"; updatedAt: string }>>;
      saveReplyTemplate(input: { id?: string; title: string; content: string; platform: "shopee-vn" | "tiktok-vn" | "lazada-vn" | "all" }): Promise<{ id: string; title: string; content: string; platform: "shopee-vn" | "tiktok-vn" | "lazada-vn" | "all"; updatedAt: string }>;
      deleteReplyTemplate(id: string): Promise<void>;
      listPlans(kind: "boost" | "flash-sale" | "rating" | "chat-replies"): Promise<Array<{ id: string; kind: "boost" | "flash-sale" | "rating" | "chat-replies"; name: string; notes: string; enabled: number; updatedAt: string }>>;
      savePlan(input: { id?: string; kind: "boost" | "flash-sale" | "rating" | "chat-replies"; name: string; notes?: string; enabled?: boolean }): Promise<{ id: string; kind: "boost" | "flash-sale" | "rating" | "chat-replies"; name: string; notes: string; enabled: number; updatedAt: string }>;
      deletePlan(id: string): Promise<void>;
      showDataFolder(): Promise<string>;
      controlWindow(control: "minimize" | "toggle-maximize" | "close"): Promise<void>;
    };
  }
}

export {};
