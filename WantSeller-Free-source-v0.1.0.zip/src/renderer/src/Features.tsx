import { useEffect, useMemo, useState, type FormEvent } from "react";
import { useRef } from "react";
import {
  ArrowDownToLine, ArrowUpFromLine, Clipboard, FileText, Plus, RefreshCw,
  Search, Trash2, ExternalLink, CircleCheck, CircleAlert, Package, Printer,
} from "lucide-react";
import type { AutomationPlan, Order, Platform, PrintDocument, ReplyTemplate, Shop } from "../../main/database";
import * as pdfjs from "pdfjs-dist";
import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjs.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

type FeatureRoute = "orders" | "print" | "inbox" | "boost" | "flash-sale" | "rating" | "chat-replies" | "settings";

const money = new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND", maximumFractionDigits: 0 });
const platformName: Record<Platform, string> = { "shopee-vn": "Shopee", "tiktok-vn": "TikTok Shop", "lazada-vn": "Lazada" };
const automationInfo: Record<AutomationPlan["kind"], { title: string; help: string; sample: string }> = {
  boost: { title: "Đẩy sản phẩm", help: "Lưu danh sách sản phẩm và khung giờ cần kiểm tra trước khi thao tác trên Seller Center.", sample: "Mỗi ngày lúc 09:00 — chọn sản phẩm còn hàng, ưu tiên SKU bán tốt 7 ngày gần nhất." },
  "flash-sale": { title: "Flash Sale", help: "Soạn trước kế hoạch chương trình, mức giá sàn và tồn kho để rà soát thủ công.", sample: "Kiểm tra giá thấp nhất, tồn khả dụng, biên lợi nhuận và thời gian chương trình trước khi đăng ký." },
  rating: { title: "Tự động đánh giá", help: "Lưu bộ quy tắc và câu trả lời gợi ý. Chưa đăng đánh giá hoặc phản hồi lên sàn.", sample: "Chỉ đề xuất phản hồi sau khi nhân viên kiểm tra đơn và nội dung đánh giá." },
  "chat-replies": { title: "Tự động trả lời chat", help: "Ghi lại quy tắc gợi ý phản hồi. Tin nhắn không được tự gửi từ ứng dụng này.", sample: "Ưu tiên câu hỏi vận chuyển; gửi nhân viên duyệt khi nội dung chưa khớp mẫu." },
};

function SectionHeader({ eyebrow, title, description, actions }: { eyebrow: string; title: string; description: string; actions?: React.ReactNode }): React.JSX.Element {
  return <div className="feature-section-heading"><div><span className="eyebrow">{eyebrow}</span><h2>{title}</h2><p>{description}</p></div>{actions && <div className="feature-actions">{actions}</div>}</div>;
}

function EmptyState({ icon, title, text, action }: { icon: React.ReactNode; title: string; text: string; action?: React.ReactNode }): React.JSX.Element {
  return <div className="feature-empty"><div className="empty-illustration">{icon}</div><h3>{title}</h3><p>{text}</p>{action}</div>;
}

export function FeaturePage({ route, shop, onNavigate }: { route: FeatureRoute; shop?: Shop; onNavigate: (route: "shops") => void }): React.JSX.Element {
  if (route === "orders") return <OrdersPage shop={shop} onNavigate={onNavigate} />;
  if (route === "print") return <PrintPage shop={shop} onNavigate={onNavigate} />;
  if (route === "inbox") return <TemplatesPage />;
  if (route === "settings") return <SettingsPage />;
  return <AutomationPage kind={route} />;
}

function OrdersPage({ shop, onNavigate }: { shop?: Shop; onNavigate: (route: "shops") => void }): React.JSX.Element {
  const [orders, setOrders] = useState<Order[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [refresh, setRefresh] = useState(0);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useEffect(() => { void window.wantSeller.listOrders(shop?.id).then(setOrders).catch(() => setError("Không đọc được dữ liệu đơn.")); }, [shop?.id, refresh]);
  const statuses = useMemo(() => [...new Set(orders.map((order) => order.status))].sort(), [orders]);
  const filtered = orders.filter((order) => (status === "all" || order.status === status) && `${order.externalId} ${order.trackingCode} ${order.status}`.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const revenue = filtered.reduce((sum, order) => sum + order.totalCents, 0);
  const margin = filtered.reduce((sum, order) => sum + order.totalCents - order.platformFeeCents - order.costCents - order.shippingCents, 0);
  async function importCsv(): Promise<void> {
    if (!shop) { setError("Chọn hoặc thêm shop trước khi nhập đơn."); return; }
    setError(""); setMessage("");
    try { const result = await window.wantSeller.importOrdersCsv(shop.id); if (!result.canceled) { setMessage(`Đã thêm ${result.imported} đơn, cập nhật ${result.updated} đơn.`); setRefresh((value) => value + 1); } }
    catch (reason) { setError(reason instanceof Error ? reason.message : "Không thể nhập CSV."); }
  }
  async function exportCsv(): Promise<void> {
    try { const result = await window.wantSeller.exportOrdersCsv(shop?.id); if (!result.canceled) setMessage(`Đã xuất ${result.count} đơn.`); }
    catch { setError("Không thể xuất CSV."); }
  }
  return <section className="feature-page">
    <SectionHeader eyebrow="QUẢN LÝ ĐƠN HÀNG" title="Đơn hàng đa shop" description={shop ? `${platformName[shop.platform]} · ${shop.name} · dữ liệu lưu trên máy` : "Tra cứu tập trung dữ liệu CSV đã nhập từ các shop"} actions={<>
      <button className="button-secondary" onClick={() => setRefresh((value) => value + 1)}><RefreshCw size={15} />Làm mới</button>
      <button className="button-secondary" onClick={() => void exportCsv()}><ArrowDownToLine size={15} />Xuất CSV</button>
      <button className="button-primary" onClick={() => void importCsv()} disabled={!shop}><ArrowUpFromLine size={15} />Nhập CSV</button>
    </>} />
    {!shop && <div className="notice info"><CircleAlert size={16} /><span>Chọn shop ở thanh bên để nhập đơn. Dữ liệu hiện có bên dưới vẫn xem và xuất được.</span><button onClick={() => onNavigate("shops")}>Thêm shop</button></div>}
    {(message || error) && <div className={error ? "notice error" : "notice success"}>{error ? <CircleAlert size={16} /> : <CircleCheck size={16} />}{error || message}<button onClick={() => { setMessage(""); setError(""); }}>Đóng</button></div>}
    <div className="metric-row"><div className="metric-card"><span>Đơn trong bộ lọc</span><strong>{filtered.length.toLocaleString("vi-VN")}</strong><small>{orders.length ? "Nguồn: CSV đã nhập" : "Chưa có dữ liệu"}</small></div><div className="metric-card"><span>Doanh thu ghi nhận</span><strong>{money.format(revenue / 100)}</strong><small>Trước phí sàn và giá vốn</small></div><div className="metric-card"><span>Lãi ước tính</span><strong className={margin < 0 ? "negative" : "positive"}>{money.format(margin / 100)}</strong><small>Doanh thu − phí − vốn − vận chuyển</small></div></div>
    <div className="table-toolbar"><label className="table-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm mã đơn hoặc vận đơn" /></label><select value={status} onChange={(event) => setStatus(event.target.value)}><option value="all">Tất cả trạng thái</option>{statuses.map((item) => <option key={item}>{item}</option>)}</select><span>{filtered.length} kết quả</span></div>
    {filtered.length ? <div className="data-table-wrap"><table className="data-table"><thead><tr><th>Mã đơn</th><th>Trạng thái</th><th>Ngày đặt</th><th>Số SP</th><th>Doanh thu</th><th>Lãi ước tính</th><th>Mã vận đơn</th></tr></thead><tbody>{filtered.map((order) => { const net = order.totalCents - order.platformFeeCents - order.costCents - order.shippingCents; return <tr key={order.id}><td className="mono">{order.externalId}</td><td><span className="status-tag">{order.status}</span></td><td>{order.orderDate || "—"}</td><td>{order.itemCount || "—"}</td><td>{money.format(order.totalCents / 100)}</td><td className={net < 0 ? "negative" : "positive"}>{money.format(net / 100)}</td><td className="mono">{order.trackingCode || "—"}</td></tr>; })}</tbody></table></div> : <EmptyState icon={<Package size={30} />} title={orders.length ? "Không có đơn khớp bộ lọc" : "Chưa có đơn hàng"} text={orders.length ? "Hãy thử từ khóa hoặc trạng thái khác." : "Nhập CSV xuất từ Seller Center. Mẫu cột: order_id, status, order_date, item_count, total_vnd, platform_fee_vnd, cost_vnd, shipping_vnd, tracking_code."} action={!orders.length && shop ? <button className="button-primary" onClick={() => void importCsv()}><ArrowUpFromLine size={15} />Chọn CSV để nhập</button> : undefined} />}
    <div className="feature-footnote">Lãi ước tính chỉ chính xác khi tệp có đủ phí sàn, giá vốn và vận chuyển. Không gửi dữ liệu lên máy chủ.</div>
  </section>;
}

function PrintPage({ shop, onNavigate }: { shop?: Shop; onNavigate: (route: "shops") => void }): React.JSX.Element {
  const [documents, setDocuments] = useState<PrintDocument[]>([]);
  const [indexedPages, setIndexedPages] = useState<Array<{ documentId: string; pageNumber: number; text: string; fileName: string }>>([]);
  const [search, setSearch] = useState("");
  const [refresh, setRefresh] = useState(0);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [indexingId, setIndexingId] = useState<string | null>(null);
  const [viewer, setViewer] = useState<{ id: string; page: number } | null>(null);
  useEffect(() => {
    void Promise.all([window.wantSeller.listPrintDocuments(shop?.id), window.wantSeller.listIndexedPdfPages()])
      .then(([items, pages]) => { setDocuments(items); setIndexedPages(pages); })
      .catch(() => setError("Không tải được danh sách file."));
  }, [shop?.id, refresh]);
  const filtered = documents.filter((item) => item.fileName.toLocaleLowerCase().includes(search.toLocaleLowerCase()));
  const query = search.trim().toLocaleLowerCase();
  const matches = query.length >= 2 ? indexedPages.flatMap((page) => {
    const at = page.text.toLocaleLowerCase().indexOf(query);
    if (at < 0) return [];
    const start = Math.max(0, at - 55); const end = Math.min(page.text.length, at + query.length + 85);
    return [{ ...page, excerpt: `${start ? "…" : ""}${page.text.slice(start, end)}${end < page.text.length ? "…" : ""}` }];
  }).slice(0, 100) : [];
  async function importPdfs(): Promise<void> {
    try { const result = await window.wantSeller.importPrintDocuments(shop?.id); if (!result.canceled) { setMessage(`Đã thêm ${result.count} PDF vào danh mục.`); setRefresh((value) => value + 1); } }
    catch { setError("Không thể thêm PDF."); }
  }
  async function indexPdf(doc: PrintDocument): Promise<void> {
    setIndexingId(doc.id); setError(""); setMessage("");
    let loadingTask: ReturnType<typeof pdfjs.getDocument> | undefined;
    try {
      const bytes = await window.wantSeller.getPrintPdfData(doc.id);
      loadingTask = pdfjs.getDocument({ data: new Uint8Array(bytes), useSystemFonts: true });
      const pdf = await loadingTask.promise;
      if (pdf.numPages > 2000) throw new Error("Tệp có hơn 2.000 trang, vượt giới hạn lập chỉ mục.");
      const pages: Array<{ pageNumber: number; text: string }> = [];
      let total = 0;
      for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber += 1) {
        const page = await pdf.getPage(pageNumber);
        const textContent = await page.getTextContent();
        const text = textContent.items.map((item) => "str" in item ? item.str : "").join(" ").replace(/\s+/g, " ").trim().slice(0, 60_000);
        total += text.length;
        if (total > 10_000_000) throw new Error("Nội dung văn bản vượt giới hạn 10 MB.");
        pages.push({ pageNumber, text });
      }
      await window.wantSeller.savePrintPdfIndex({ id: doc.id, pages });
      setMessage(pages.some((page) => page.text) ? `Đã lập chỉ mục ${pages.length} trang của “${doc.fileName}”.` : `PDF đã đọc được ${pages.length} trang nhưng không có lớp văn bản có thể tìm kiếm; file có thể là bản scan.`);
      setRefresh((value) => value + 1);
      await loadingTask.destroy();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không thể đọc PDF. Tệp có thể hỏng hoặc đã bị di chuyển.");
      await loadingTask?.destroy();
    } finally { setIndexingId(null); }
  }
  return <section className="feature-page">
    <SectionHeader eyebrow="KHO PHIẾU IN" title="Quản lý file in" description="Lập danh mục PDF trên máy, mở bằng trình xem PDF của Windows và tìm nhanh theo tên file." actions={<><button className="button-secondary" onClick={() => setRefresh((value) => value + 1)}><RefreshCw size={15} />Làm mới</button><button className="button-primary" onClick={() => void importPdfs()}><Plus size={15} />Thêm PDF</button></>} />
    {!shop && <div className="notice info"><CircleAlert size={16} /><span>File có thể thêm vào kho chung, hoặc chọn shop để gắn tài liệu cho shop đó.</span><button onClick={() => onNavigate("shops")}>Chọn shop</button></div>}
    {error && <div className="notice error"><CircleAlert size={16} /><span>{error}</span><button onClick={() => setError("")}>Đóng</button></div>}
    {message && <div className="notice success"><CircleCheck size={16} /><span>{message}</span><button onClick={() => setMessage("")}>Đóng</button></div>}
    <div className="table-toolbar"><label className="table-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Tìm tên file, mã đơn hoặc mã vận đơn" /></label><span>{filtered.length} tệp · {formatBytes(filtered.reduce((sum, item) => sum + item.sizeBytes, 0))}</span></div>
    {query.length >= 2 && <div className="pdf-search-results"><div className="summary-card-heading"><strong>{matches.length} trang có kết quả tìm kiếm nội dung</strong><small>Chỉ tìm trong PDF đã lập chỉ mục</small></div>{matches.map((match) => <button className="pdf-match" key={`${match.documentId}-${match.pageNumber}`} onClick={() => setViewer({ id: match.documentId, page: match.pageNumber })}><FileText size={15} /><span><strong>{match.fileName} · Trang {match.pageNumber}</strong><small>{match.excerpt}</small></span></button>)}{matches.length === 0 && <p>Chưa có kết quả nội dung. Lập chỉ mục một PDF bên dưới hoặc thử tên file.</p>}</div>}
    {filtered.length ? <div className="document-grid">{filtered.map((doc) => <article className="document-card" key={doc.id}><div className="document-icon"><FileText size={23} /></div><div className="document-info"><strong title={doc.fileName}>{doc.fileName}</strong><span>{formatBytes(doc.sizeBytes)} · {doc.pageCount ? `${doc.pageCount} trang đã lập chỉ mục` : "Chưa lập chỉ mục"}</span><small>{doc.shopId ? shop?.name ?? "Tài liệu shop" : "Kho chung"}</small></div><div className="document-actions"><button className="icon-button" aria-label="Xem trước PDF" onClick={() => setViewer({ id: doc.id, page: 1 })}><Search size={16} /></button><button className="icon-button" aria-label="Mở PDF ngoài ứng dụng" onClick={() => void window.wantSeller.openPrintDocument(doc.id)}><ExternalLink size={15} /></button><button className="icon-button" aria-label="Lập chỉ mục PDF" disabled={indexingId === doc.id} title="Lập chỉ mục nội dung" onClick={() => void indexPdf(doc)}><RefreshCw size={15} /></button><button className="icon-button danger-hover" aria-label="Gỡ khỏi danh mục" onClick={async () => { await window.wantSeller.removePrintDocument(doc.id); setRefresh((value) => value + 1); }}><Trash2 size={15} /></button></div></article>)}</div> : <EmptyState icon={<Printer size={29} />} title="Chưa có phiếu in trong kho" text="Thêm PDF để lập chỉ mục nội dung, tìm mã đơn theo trang và mở bản xem trước. Tệp gốc vẫn nằm ở vị trí hiện tại." action={<button className="button-primary" onClick={() => void importPdfs()}><Plus size={15} />Thêm PDF</button>} />}
    <div className="feature-footnote">PDF được đọc và lập chỉ mục cục bộ. Lớp văn bản được tìm kiếm; tài liệu scan không có OCR. Giới hạn hiện tại: 50 MB và 2.000 trang mỗi tệp.</div>
    {viewer && <PdfViewer documentId={viewer.id} initialPage={viewer.page} onClose={() => setViewer(null)} />}
  </section>;
}

type PdfDocument = Awaited<ReturnType<typeof pdfjs.getDocument>["promise"]>;
function PdfViewer({ documentId, initialPage, onClose }: { documentId: string; initialPage: number; onClose: () => void }): React.JSX.Element {
  const [pdf, setPdf] = useState<PdfDocument | null>(null);
  const [pageNumber, setPageNumber] = useState(initialPage);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(true);
  const canvas = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    let disposed = false;
    let task: ReturnType<typeof pdfjs.getDocument> | undefined;
    void window.wantSeller.getPrintPdfData(documentId).then((bytes) => {
      if (disposed) return;
      task = pdfjs.getDocument({ data: new Uint8Array(bytes), useSystemFonts: true });
      return task.promise;
    }).then((loaded) => { if (!disposed && loaded) { setPdf(loaded); setBusy(false); } })
      .catch((reason: unknown) => { if (!disposed) { setError(reason instanceof Error ? reason.message : "Không thể mở PDF."); setBusy(false); } });
    return () => { disposed = true; void task?.destroy(); };
  }, [documentId]);
  useEffect(() => {
    if (!pdf || !canvas.current) return;
    let renderTask: ReturnType<Awaited<ReturnType<PdfDocument["getPage"]>>["render"]> | undefined;
    let disposed = false;
    void pdf.getPage(pageNumber).then((page) => {
      if (disposed || !canvas.current) return;
      const base = page.getViewport({ scale: 1 });
      const width = Math.max(320, Math.min(900, canvas.current.parentElement?.clientWidth ?? 800));
      const viewport = page.getViewport({ scale: Math.min(1.5, width / base.width) });
      const element = canvas.current;
      element.width = Math.floor(viewport.width);
      element.height = Math.floor(viewport.height);
      const context = element.getContext("2d");
      if (!context) throw new Error("Không tạo được canvas để xem PDF.");
      renderTask = page.render({ canvas: element, canvasContext: context, viewport });
      return renderTask.promise;
    }).catch((reason: unknown) => { if (!disposed && !(reason instanceof Error && reason.name === "RenderingCancelledException")) setError(reason instanceof Error ? reason.message : "Lỗi khi dựng trang PDF."); });
    return () => { disposed = true; renderTask?.cancel(); };
  }, [pdf, pageNumber]);
  return <div className="pdf-modal-backdrop" onMouseDown={onClose}><section className="pdf-modal" role="dialog" aria-modal="true" aria-label="Xem trước PDF" onMouseDown={(event) => event.stopPropagation()}><header><div><strong>Xem phiếu in</strong><span>{pdf ? `${pageNumber} / ${pdf.numPages}` : "Đang tải tài liệu…"}</span></div><div className="pdf-controls"><button className="button-secondary" disabled={!pdf || pageNumber <= 1} onClick={() => setPageNumber((n) => Math.max(1, n - 1))}>Trang trước</button><button className="button-secondary" disabled={!pdf || pageNumber >= pdf.numPages} onClick={() => setPageNumber((n) => Math.min(pdf?.numPages ?? 1, n + 1))}>Trang sau</button><button className="icon-button" aria-label="Đóng xem trước" onClick={onClose}>×</button></div></header><div className="pdf-canvas-area">{busy && <span>Đang đọc PDF…</span>}{error && <div className="notice error">{error}</div>}<canvas ref={canvas} />{pdf && <span className="pdf-print-hint">Dùng Ctrl+P để mở hộp thoại in của Windows.</span>}</div></section></div>;
}

function TemplatesPage(): React.JSX.Element {
  const [templates, setTemplates] = useState<ReplyTemplate[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [platform, setPlatform] = useState<Platform | "all">("all");
  const [notice, setNotice] = useState("");
  const [refresh, setRefresh] = useState(0);
  useEffect(() => { void window.wantSeller.listReplyTemplates().then(setTemplates); }, [refresh]);
  async function save(event: FormEvent<HTMLFormElement>): Promise<void> { event.preventDefault(); const saved = await window.wantSeller.saveReplyTemplate({ title, content, platform }); setTitle(""); setContent(""); setPlatform("all"); setNotice(`Đã lưu mẫu “${saved.title}” trên máy.`); setRefresh((value) => value + 1); }
  async function copy(template: ReplyTemplate): Promise<void> { await navigator.clipboard.writeText(template.content); setNotice(`Đã sao chép “${template.title}”. Dán và kiểm tra trong Seller Center khi phù hợp.`); }
  return <section className="feature-page"><SectionHeader eyebrow="CHAT ĐA SÀN" title="Thư viện phản hồi" description="Quản lý câu trả lời nhanh và sao chép vào Seller Center khi bạn đã kiểm tra hội thoại." />
    <div className="notice info"><CircleAlert size={16} /><span>Phiên bản này chưa kết nối inbox và không tự gửi tin nhắn. Mẫu chỉ lưu cục bộ trên máy.</span></div>
    {notice && <div className="notice success"><CircleCheck size={16} /><span>{notice}</span><button onClick={() => setNotice("")}>Đóng</button></div>}
    <div className="two-column-layout"><form className="editor-card" onSubmit={(event) => void save(event)}><span className="eyebrow">TẠO MẪU MỚI</span><h3>Soạn phản hồi</h3><label className="field-label">Tên mẫu<input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={80} placeholder="Ví dụ: Xác nhận thời gian giao hàng" required /></label><label className="field-label">Áp dụng cho<select value={platform} onChange={(event) => setPlatform(event.target.value as Platform | "all")}><option value="all">Tất cả nền tảng</option><option value="shopee-vn">Shopee</option><option value="tiktok-vn">TikTok Shop</option><option value="lazada-vn">Lazada</option></select></label><label className="field-label">Nội dung<textarea value={content} onChange={(event) => setContent(event.target.value)} rows={6} maxLength={4000} placeholder="Chào {{ten_khach}}, shop đã nhận được câu hỏi của bạn…" required /></label><p className="form-hint">Có thể dùng các biến gợi ý như <code>{"{{ten_khach}}"}</code>, <code>{"{{ma_don}}"}</code> khi sao chép.</p><button className="button-primary" type="submit"><Plus size={15} />Lưu mẫu</button></form>
      <div className="template-list"><div className="summary-card-heading"><div><span className="eyebrow">MẪU ĐÃ LƯU</span><h3>{templates.length} mẫu phản hồi</h3></div></div>{templates.length ? templates.map((template) => <article className="template-card" key={template.id}><header><div><strong>{template.title}</strong><span>{template.platform === "all" ? "Tất cả nền tảng" : platformName[template.platform]}</span></div><button className="icon-button danger-hover" aria-label="Xóa mẫu" onClick={async () => { await window.wantSeller.deleteReplyTemplate(template.id); setRefresh((value) => value + 1); }}><Trash2 size={15} /></button></header><p>{template.content}</p><footer><button className="button-secondary" onClick={() => void copy(template)}><Clipboard size={14} />Sao chép</button></footer></article>) : <EmptyState icon={<Clipboard size={28} />} title="Chưa có mẫu" text="Tạo mẫu để chuẩn hóa câu trả lời thường dùng." />}</div></div>
  </section>;
}

function AutomationPage({ kind }: { kind: AutomationPlan["kind"] }): React.JSX.Element {
  const info = automationInfo[kind];
  const [plans, setPlans] = useState<AutomationPlan[]>([]);
  const [name, setName] = useState("");
  const [notes, setNotes] = useState("");
  const [refresh, setRefresh] = useState(0);
  const [message, setMessage] = useState("");
  useEffect(() => { void window.wantSeller.listPlans(kind).then(setPlans); }, [kind, refresh]);
  async function create(event: FormEvent<HTMLFormElement>): Promise<void> { event.preventDefault(); await window.wantSeller.savePlan({ kind, name, notes, enabled: false }); setName(""); setNotes(""); setMessage("Đã lưu kế hoạch ở trạng thái bản nháp."); setRefresh((value) => value + 1); }
  return <section className="feature-page"><SectionHeader eyebrow="KẾ HOẠCH TỰ ĐỘNG HÓA" title={info.title} description={info.help} />
    <div className="notice info"><CircleAlert size={16} /><span>Kế hoạch được lưu cục bộ ở trạng thái nháp. Ứng dụng chưa đăng nhập hoặc tự thao tác trên sàn.</span></div>{message && <div className="notice success"><CircleCheck size={16} />{message}<button onClick={() => setMessage("")}>Đóng</button></div>}
    <div className="two-column-layout"><form className="editor-card" onSubmit={(event) => void create(event)}><span className="eyebrow">KẾ HOẠCH MỚI</span><h3>Ghi chú thao tác</h3><label className="field-label">Tên kế hoạch<input value={name} onChange={(event) => setName(event.target.value)} maxLength={100} placeholder={info.title} required /></label><label className="field-label">Quy tắc và bước kiểm tra<textarea value={notes} onChange={(event) => setNotes(event.target.value)} rows={7} maxLength={4000} placeholder={info.sample} /></label><button className="button-primary" type="submit"><Plus size={15} />Lưu bản nháp</button></form>
      <div className="template-list"><div className="summary-card-heading"><div><span className="eyebrow">KHO KẾ HOẠCH</span><h3>{plans.length} kế hoạch đã lưu</h3></div></div>{plans.length ? plans.map((plan) => <article className="plan-card" key={plan.id}><header><div><strong>{plan.name}</strong><span><span className="status-dot draft-dot" />Bản nháp · {new Date(plan.updatedAt).toLocaleDateString("vi-VN")}</span></div><button className="icon-button danger-hover" aria-label="Xóa kế hoạch" onClick={async () => { await window.wantSeller.deletePlan(plan.id); setRefresh((value) => value + 1); }}><Trash2 size={15} /></button></header><p>{plan.notes || "Chưa có ghi chú"}</p></article>) : <EmptyState icon={<FileText size={27} />} title="Chưa có kế hoạch" text="Soạn quy tắc và checklist trước khi thực hiện thủ công trên sàn." />}</div></div>
  </section>;
}

function SettingsPage(): React.JSX.Element {
  const [info, setInfo] = useState<{ name: string; version: string; mode: "free"; dataPath: string }>();
  useEffect(() => { void window.wantSeller.getInfo().then(setInfo); }, []);
  return <section className="feature-page"><SectionHeader eyebrow="CẤU HÌNH ỨNG DỤNG" title="Cài đặt hệ thống" description="Quản lý dữ liệu cục bộ, quyền riêng tư và phiên bản ứng dụng." />
    <div className="settings-grid"><article className="settings-card"><div className="settings-icon"><CircleCheck size={21} /></div><div><h3>WantSeller miễn phí</h3><p>Phiên bản {info?.version ?? "…"} · không yêu cầu HWID hoặc mã kích hoạt.</p></div><span className="status-pill status-connected">Đã mở khóa</span></article>
      <article className="settings-card"><div className="settings-icon"><FileText size={21} /></div><div><h3>Dữ liệu của bạn</h3><p>Shop, đơn CSV, mẫu trả lời và kế hoạch được lưu trong hồ sơ người dùng trên máy này.</p><small className="data-path">{info?.dataPath}</small><button className="button-secondary" onClick={() => void window.wantSeller.showDataFolder()}>Mở thư mục dữ liệu</button></div></article>
      <article className="settings-card"><div className="settings-icon"><CircleAlert size={21} /></div><div><h3>Kết nối nền tảng</h3><p>Chưa bật API chính thức. Kết nối sàn sẽ cần OAuth và quyền ứng dụng do từng nền tảng cấp.</p></div><span className="status-pill status-disconnected">Chưa kết nối</span></article>
      <article className="settings-card"><div className="settings-icon"><Package size={21} /></div><div><h3>Quyền riêng tư</h3><p>Không thu thập thông tin chẩn đoán và không gửi dữ liệu shop lên máy chủ trong bản hiện tại.</p></div><span className="status-pill status-connected">Cục bộ</span></article></div>
  </section>;
}

function formatBytes(bytes: number): string { if (bytes < 1024) return `${bytes} B`; const kb = bytes / 1024; if (kb < 1024) return `${kb.toFixed(1)} KB`; return `${(kb / 1024).toFixed(1)} MB`; }
