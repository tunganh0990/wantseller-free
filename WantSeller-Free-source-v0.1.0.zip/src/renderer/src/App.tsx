import { useEffect, useState, type FormEvent } from "react";
import {
  Bell,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  FileText,
  Grid2X2,
  Menu,
  MessageCircle,
  Minus,
  Package,
  Plus,
  Printer,
  RefreshCw,
  Rocket,
  Search,
  Settings,
  ShoppingBag,
  Star,
  X,
} from "lucide-react";
import { FeaturePage } from "./Features";
import shopeeLogo from "../assets/reference/shopee.png";
import tiktokLogo from "../assets/reference/tiktok.png";
import lazadaLogo from "../assets/reference/lazada.png";
import type { Order } from "../../main/database";

type Platform = "shopee-vn" | "tiktok-vn" | "lazada-vn";
type ShopStatus = "disconnected" | "connected" | "needs-auth";
type Shop = {
  id: string;
  name: string;
  platform: Platform;
  status: ShopStatus;
  createdAt: string;
};
type Route =
  | "shops"
  | "orders"
  | "print"
  | "inbox"
  | "boost"
  | "flash-sale"
  | "rating"
  | "chat-replies"
  | "settings";

const navigation: Array<{ id: Route; label: string; icon: typeof ShoppingBag }> = [
  { id: "shops", label: "Shop của tôi", icon: ShoppingBag },
  { id: "orders", label: "Xử Lý Đơn Hàng", icon: Package },
  { id: "print", label: "Quản lý file in", icon: Printer },
  { id: "inbox", label: "Chat Đa Sàn", icon: MessageCircle },
  { id: "boost", label: "Đẩy sản phẩm", icon: Rocket },
  { id: "flash-sale", label: "Flash Sale", icon: Grid2X2 },
  { id: "rating", label: "Tự động đánh giá", icon: Star },
  { id: "chat-replies", label: "Tự động trả lời chat", icon: MessageCircle },
];

const platformLabels: Record<Platform, string> = {
  "shopee-vn": "Shopee",
  "tiktok-vn": "TikTok Shop",
  "lazada-vn": "Lazada",
};
const platformLogos: Record<Platform, string> = {
  "shopee-vn": shopeeLogo,
  "tiktok-vn": tiktokLogo,
  "lazada-vn": lazadaLogo,
};
const dashboardMoney = new Intl.NumberFormat("vi-VN", {
  style: "currency",
  currency: "VND",
  maximumFractionDigits: 0,
});

const routeTitles: Record<Route, string> = {
  shops: "Shop của tôi",
  orders: "Xử Lý Đơn Hàng",
  print: "Quản lý file in",
  inbox: "Chat Đa Sàn",
  boost: "Đẩy sản phẩm",
  "flash-sale": "Flash Sale",
  rating: "Tự động đánh giá",
  "chat-replies": "Tự động trả lời chat",
  settings: "Cài đặt hệ thống",
};

function App(): React.JSX.Element {
  const [shops, setShops] = useState<Shop[]>([]);
  const [selectedShopId, setSelectedShopId] = useState<string | null>(null);
  const [route, setRoute] = useState<Route>("shops");
  const [query, setQuery] = useState("");
  const [showShopModal, setShowShopModal] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [appVersion, setAppVersion] = useState("");
  const [loadError, setLoadError] = useState("");

  async function refreshShops(): Promise<void> {
    try {
      const result = await window.wantSeller.listShops();
      setShops(result);
      setSelectedShopId((current) =>
        current && result.some((shop) => shop.id === current)
          ? current
          : result[0]?.id ?? null,
      );
      setLoadError("");
    } catch {
      setLoadError("Không tải được danh sách shop. Hãy thử làm mới.");
    }
  }

  useEffect(() => {
    void refreshShops();
    void window.wantSeller.getInfo().then((info) => setAppVersion(info.version));
  }, []);

  const visibleShops = shops.filter((shop) =>
    shop.name.toLocaleLowerCase().includes(query.toLocaleLowerCase()),
  );
  const selectedShop = shops.find((shop) => shop.id === selectedShopId);

  function navigate(nextRoute: Route): void {
    setRoute(nextRoute);
  }

  return (
    <div className="app-window">
      <header className="title-bar">
        <div className="brand-lockup">
          <div className="brand-mark">W</div>
          <span className="brand-name">WantSeller</span>
          <span className="brand-edition">MIỄN PHÍ</span>
        </div>
        <div className="title-bar-tools">
          <button className="icon-button" aria-label="Trợ giúp" onClick={() => setShowHelp(true)}>
            <CircleHelp size={16} />
          </button>
          <button
            className="icon-button"
            aria-label="Cài đặt hệ thống"
            onClick={() => navigate("settings")}
          >
            <Settings size={16} />
          </button>
          <div className="window-separator" />
          <button
            className="window-control"
            aria-label="Thu nhỏ"
            onClick={() => void window.wantSeller.controlWindow("minimize")}
          >
            <Minus size={14} />
          </button>
          <button
            className="window-control"
            aria-label="Phóng to hoặc thu nhỏ"
            onClick={() => void window.wantSeller.controlWindow("toggle-maximize")}
          >
            <span className="maximize-glyph" />
          </button>
          <button
            className="window-control close-control"
            aria-label="Đóng"
            onClick={() => void window.wantSeller.controlWindow("close")}
          >
            <X size={15} />
          </button>
        </div>
      </header>

      <div className="toolbar">
        <div className="toolbar-left">
          <button
            className="toolbar-icon"
            aria-label="Thu gọn danh sách shop"
            onClick={() => setCollapsed((value) => !value)}
          >
            <Menu size={18} />
          </button>
          <span className="toolbar-context">
            {selectedShop?.name ?? routeTitles[route]}
          </span>
          <div className="toolbar-divider" />
          <button className="action-button" onClick={() => navigate("print")}>
            <Printer size={16} />
            <span>Quản lý file in</span>
          </button>
          <button className="action-button" onClick={() => navigate("inbox")}>
            <MessageCircle size={16} />
            <span>Chat Đa Sàn</span>
          </button>
          <button className="action-button action-notifications" onClick={() => setShowNotifications(true)}>
            <Bell size={16} />
            <span>Thông báo</span>
          </button>
        </div>
        <button className="menu-button" onClick={() => setShowShopModal(true)}>
          <Plus size={16} />
          <span>Thêm Shop</span>
          <ChevronDown size={13} />
        </button>
      </div>

      <div className="workspace">
        <aside className={"sidebar" + (collapsed ? " sidebar-collapsed" : "")}>
          {!collapsed && <div className="sidebar-heading">CHỨC NĂNG</div>}
          <nav className="primary-navigation" aria-label="Chức năng">
            {navigation.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                className={
                  "navigation-item" + (route === id ? " navigation-item-active" : "")
                }
                onClick={() => navigate(id)}
                title={collapsed ? label : undefined}
              >
                <Icon size={17} strokeWidth={1.9} />
                <span>{label}</span>
                {id === "inbox" && !collapsed && (
                  <span className="navigation-beta">BETA</span>
                )}
              </button>
            ))}
          </nav>

          <div className="sidebar-divider" />
          <div className="shop-list-header">
            {!collapsed && <span>SHOP CỦA TÔI</span>}
            <button
              className="small-icon-button"
              aria-label="Thêm shop"
              onClick={() => setShowShopModal(true)}
            >
              <Plus size={15} />
            </button>
          </div>
          {!collapsed && (
            <>
              <label className="shop-search">
                <Search size={14} />
                <input
                  aria-label="Tìm shop"
                  placeholder="Tìm tên Shop"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
              </label>
              <div className="shop-list">
                {visibleShops.map((shop) => (
                  <button
                    key={shop.id}
                    className={
                      "shop-item" +
                      (selectedShopId === shop.id ? " shop-item-active" : "")
                    }
                    onClick={() => {
                      setSelectedShopId(shop.id);
                      setRoute("shops");
                    }}
                  >
                    <span className={"shop-platform-icon platform-" + shop.platform}>
                      <img src={platformLogos[shop.platform]} alt="" />
                    </span>
                    <span className="shop-item-name">{shop.name}</span>
                    <span
                      className={"connection-dot connection-" + shop.status}
                      title={shop.status}
                    />
                  </button>
                ))}
                {visibleShops.length === 0 && (
                  <div className="shop-list-empty">
                    {query ? "Không tìm thấy shop" : "Chưa có shop"}
                  </div>
                )}
              </div>
            </>
          )}

          <div className="sidebar-bottom">
            <button
              className={
                "navigation-item" +
                (route === "settings" ? " navigation-item-active" : "")
              }
              onClick={() => navigate("settings")}
              title={collapsed ? "Cài đặt" : undefined}
            >
              <Settings size={17} strokeWidth={1.9} />
              <span>Cài đặt</span>
            </button>
            {!collapsed && (
              <div className="sidebar-version">
                WantSeller · {appVersion || "0.1.0"}
              </div>
            )}
          </div>
        </aside>

        <main className="main-area">
          <div className="page-heading">
            <div>
              <div className="breadcrumb">WantSeller / {routeTitles[route]}</div>
              <h1>{routeTitles[route]}</h1>
              <p>
                {selectedShop
                  ? platformLabels[selectedShop.platform] + " · " + selectedShop.name
                  : "Quản lý hoạt động bán hàng trong một nơi"}
              </p>
            </div>
            <div className="page-actions">
              <button className="button-secondary" onClick={() => void refreshShops()}>
                <RefreshCw size={15} />
                Làm mới
              </button>
              <button
                className="button-primary"
                onClick={() =>
                  route === "shops" ? setShowShopModal(true) : setRoute("shops")
                }
              >
                <Plus size={16} />
                {route === "shops" ? "Thêm Shop mới" : "Chọn shop"}
              </button>
            </div>
          </div>

          {loadError && (
            <div className="load-error" role="alert">
              {loadError}
              <button onClick={() => void refreshShops()}>Thử lại</button>
            </div>
          )}

          {route === "shops" ? (
            <ShopOverview
              shops={shops}
              selectedShop={selectedShop}
              onAdd={() => setShowShopModal(true)}
              onNavigate={navigate}
            />
          ) : (
            <FeaturePage route={route} shop={selectedShop} onNavigate={navigate} />
          )}
        </main>
      </div>

      {showShopModal && (
        <AddShopModal
          onClose={() => setShowShopModal(false)}
          onSaved={(shop) => {
            setShops((current) => [...current, shop]);
            setSelectedShopId(shop.id);
            setRoute("shops");
            setShowShopModal(false);
          }}
        />
      )}
      {showHelp && <InfoModal title="Trợ giúp WantSeller Free" onClose={() => setShowHelp(false)}>
        <p>Ứng dụng lưu shop, đơn CSV, PDF, mẫu trả lời và kế hoạch trên máy này. Bản hiện tại không cần HWID, không tự đăng nhập và chưa gửi dữ liệu lên nền tảng.</p>
        <h3>Nhập đơn</h3><p>Chọn một shop trước, rồi mở <strong>Xử Lý Đơn Hàng → Nhập CSV</strong>. Các cột được nhận gồm mã đơn, trạng thái, ngày, số lượng, tổng, phí sàn, giá vốn, vận chuyển và mã vận đơn. Đơn trùng mã trong cùng shop được cập nhật.</p>
        <h3>Kho PDF</h3><p>Thêm PDF, bấm biểu tượng lập chỉ mục để tìm văn bản theo trang. File scan ảnh chưa hỗ trợ OCR.</p>
      </InfoModal>}
      {showNotifications && <InfoModal title="Thông báo" onClose={() => setShowNotifications(false)}>
        <p>Chưa có thông báo từ sàn vì tài khoản chưa được kết nối qua API chính thức.</p>
        <p>Ứng dụng hiện không theo dõi đơn/chat ở nền. Hãy nhập dữ liệu CSV mới để cập nhật danh sách đơn.</p>
      </InfoModal>}
    </div>
  );
}

function ShopOverview({
  shops,
  selectedShop,
  onAdd,
  onNavigate,
}: {
  shops: Shop[];
  selectedShop?: Shop;
  onAdd: () => void;
  onNavigate: (route: Route) => void;
}): React.JSX.Element {
  const [orders, setOrders] = useState<Order[]>([]);
  const [documentCount, setDocumentCount] = useState(0);
  useEffect(() => {
    void Promise.all([
      window.wantSeller.listOrders(selectedShop?.id),
      window.wantSeller.listPrintDocuments(selectedShop?.id),
    ]).then(([orders, documents]) => {
      setOrders(orders);
      setDocumentCount(documents.length);
    }).catch(() => undefined);
  }, [selectedShop?.id, shops.length]);
  const orderCount = orders.length;
  const revenueCents = orders.reduce((sum, order) => sum + order.totalCents, 0);
  const marginCents = orders.reduce((sum, order) => sum + order.totalCents - order.platformFeeCents - order.costCents - order.shippingCents, 0);
  const zeroExpenseCount = orders.filter((order) => order.totalCents > 0 && order.platformFeeCents === 0 && order.costCents === 0 && order.shippingCents === 0).length;
  const trendDays = createSalesTrend(orders);
  const chartMax = Math.max(...trendDays.map((day) => day.revenueCents), 1);
  if (shops.length === 0) {
    return (
      <div className="empty-card">
        <div className="empty-illustration">
          <ShoppingBag size={34} strokeWidth={1.5} />
        </div>
        <h2>Thêm shop đầu tiên của bạn</h2>
        <p>
          Thêm shop để quản lý phiên làm việc, đơn hàng, hội thoại và phiếu in.
        </p>
        <button className="button-primary" onClick={onAdd}>
          <Plus size={16} />
          Thêm Shop mới
        </button>
      </div>
    );
  }

  return (
    <section className="dashboard-grid">
      <div className="summary-card summary-card-wide">
        <div className="summary-card-heading">
          <div>
            <span className="eyebrow">TỔNG QUAN SHOP</span>
            <h2>{selectedShop?.name ?? "Chọn shop để xem chi tiết"}</h2>
          </div>
          {selectedShop && (
            <span className={"status-pill status-" + selectedShop.status}>
              <span className={"connection-dot connection-" + selectedShop.status} />
              {selectedShop.status === "connected" ? "Đang kết nối" : "Chưa kết nối"}
            </span>
          )}
        </div>
        <div className="overview-stats">
          <Stat label="Đơn đã nhập" value={orderCount.toLocaleString("vi-VN")} />
          <Stat label="Doanh thu ghi nhận" value={dashboardMoney.format(revenueCents / 100)} />
          <Stat label="Lãi ước tính" value={dashboardMoney.format(marginCents / 100)} />
          <Stat label="Phiếu PDF" value={documentCount.toLocaleString("vi-VN")} />
        </div>
        <div className="sales-trend">
          <div className="sales-trend-heading"><strong>Doanh thu 7 ngày</strong><span>Dựa trên ngày đặt trong CSV</span></div>
          <div className="sales-trend-chart" aria-label="Biểu đồ doanh thu bảy ngày">
            {trendDays.map((day) => {
              const height = day.revenueCents > 0 ? Math.max(4, (day.revenueCents / chartMax) * 100) : 0;
              return <div className="sales-trend-day" key={day.key} title={day.label + ": " + dashboardMoney.format(day.revenueCents / 100) + " · " + day.orderCount + " đơn"}>
                <div className="sales-trend-track"><span className="sales-trend-bar" style={{ height: String(height) + "%" }} /></div>
                <small>{day.label}</small>
              </div>;
            })}
          </div>
        </div>
        <div className="data-note">
          {zeroExpenseCount ? zeroExpenseCount + " đơn đang ghi nhận chi phí bằng 0; hãy kiểm tra CSV trước khi tin vào lãi ước tính. " : ""}
          Đơn và PDF là dữ liệu đã nhập cục bộ; biểu đồ chỉ tính ngày đọc được từ CSV, chưa đồng bộ nền tảng.
        </div>
      </div>
      <Shortcut
        icon={<Package size={18} />}
        tone="shortcut-orders"
        title="Xử lý đơn hàng"
        description="Xem danh sách và trạng thái đồng bộ"
        onClick={() => onNavigate("orders")}
      />
      <Shortcut
        icon={<FileText size={18} />}
        tone="shortcut-print"
        title="Kho phiếu in"
        description="Tìm đơn và mã vận đơn trong PDF"
        onClick={() => onNavigate("print")}
      />
      <Shortcut
        icon={<MessageCircle size={18} />}
        tone="shortcut-chat"
        title="Chat Đa Sàn"
        description="Quản lý hội thoại từ các shop"
        badge="BETA"
        onClick={() => onNavigate("inbox")}
      />
      <div className="summary-card">
        <div className="summary-card-heading">
          <div>
            <span className="eyebrow">SHOP ĐÃ THÊM</span>
            <h2>Danh sách kết nối</h2>
          </div>
          <span className="count-badge">{shops.length}</span>
        </div>
        <div className="compact-shop-list">
          {shops.map((shop) => (
            <div className="compact-shop-row" key={shop.id}>
              <span className={"shop-platform-icon platform-" + shop.platform}>
                <img src={platformLogos[shop.platform]} alt="" />
              </span>
              <div className="compact-shop-copy">
                <strong>{shop.name}</strong>
                <small>{platformLabels[shop.platform]}</small>
              </div>
              <span className={"connection-dot connection-" + shop.status} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }): React.JSX.Element {
  return (
    <div className="overview-stat">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

function createSalesTrend(orders: Order[]): Array<{ key: string; label: string; revenueCents: number; orderCount: number }> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    const key = localDateKey(date);
    return { key, label: date.toLocaleDateString("vi-VN", { weekday: "short" }), revenueCents: 0, orderCount: 0 };
  });
  const byDate = new Map(days.map((day) => [day.key, day]));
  for (const order of orders) {
    const key = orderDateKey(order.orderDate);
    const day = key ? byDate.get(key) : undefined;
    if (!day) continue;
    day.revenueCents += order.totalCents;
    day.orderCount += 1;
  }
  return days;
}

function localDateKey(date: Date): string {
  return String(date.getFullYear()) + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
}

function orderDateKey(value: string | null): string | undefined {
  if (!value) return undefined;
  const source = value.trim();
  const yearFirst = source.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (yearFirst) return yearFirst[1] + "-" + yearFirst[2].padStart(2, "0") + "-" + yearFirst[3].padStart(2, "0");
  const dayFirst = source.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
  if (dayFirst) return dayFirst[3] + "-" + dayFirst[2].padStart(2, "0") + "-" + dayFirst[1].padStart(2, "0");
  const parsed = new Date(source);
  return Number.isNaN(parsed.getTime()) ? undefined : localDateKey(parsed);
}

function Shortcut({
  icon,
  tone,
  title,
  description,
  badge,
  onClick,
}: {
  icon: React.ReactNode;
  tone: string;
  title: string;
  description: string;
  badge?: string;
  onClick: () => void;
}): React.JSX.Element {
  return (
    <button className="shortcut-card" onClick={onClick}>
      <span className={"shortcut-icon " + tone}>{icon}</span>
      <span className="shortcut-copy">
        <strong>{title}</strong>
        <small>{description}</small>
      </span>
      {badge && <span className="badge-beta">{badge}</span>}
      <ChevronRight className="shortcut-arrow" size={17} />
    </button>
  );
}

function AddShopModal({
  onClose,
  onSaved,
}: {
  onClose: () => void;
  onSaved: (shop: Shop) => void;
}): React.JSX.Element {
  const [name, setName] = useState("");
  const [platform, setPlatform] = useState<Platform>("shopee-vn");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    setSaving(true);
    setError("");

    try {
      const shop = await window.wantSeller.createShop({ name, platform });
      onSaved(shop);
    } catch {
      setError("Không lưu được shop. Tên shop có thể đã tồn tại trên sàn này.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <section
        className="shop-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-shop-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <header className="modal-header">
          <div>
            <span className="eyebrow">QUẢN LÝ SHOP CỤC BỘ</span>
            <h2 id="add-shop-title">Thêm Shop mới</h2>
          </div>
          <button className="icon-button" aria-label="Đóng" onClick={onClose}>
            <X size={18} />
          </button>
        </header>
        <form onSubmit={(event) => void submit(event)}>
          <label className="field-label">
            Nền tảng
            <select
              value={platform}
              onChange={(event) => setPlatform(event.target.value as Platform)}
            >
              <option value="shopee-vn">Shopee</option>
              <option value="tiktok-vn">TikTok Shop</option>
              <option value="lazada-vn">Lazada</option>
            </select>
          </label>
          <label className="field-label">
            Tên hiển thị
            <input
              autoFocus
              value={name}
              onChange={(event) => setName(event.target.value)}
              maxLength={80}
              placeholder="Ví dụ: Shop Hà Nội"
              required
            />
          </label>
          {error && <p className="form-error" role="alert">{error}</p>}
          <p className="form-hint">
            Shop được lưu trên máy. Kết nối tài khoản sẽ dùng API/OAuth chính thức khi nền tảng cấp quyền.
          </p>
          <footer className="modal-footer">
            <button type="button" className="button-secondary" onClick={onClose}>
              Hủy
            </button>
            <button type="submit" className="button-primary" disabled={saving}>
              {saving ? "Đang lưu…" : "Thêm Shop"}
            </button>
          </footer>
        </form>
      </section>
    </div>
  );
}

function InfoModal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }): React.JSX.Element {
  return <div className="modal-backdrop" onMouseDown={onClose}><section className="shop-modal info-modal" role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => event.stopPropagation()}><header className="modal-header"><h2>{title}</h2><button className="icon-button" aria-label="Đóng" onClick={onClose}><X size={17} /></button></header><div className="info-modal-body">{children}</div><footer className="modal-footer"><button className="button-primary" onClick={onClose}>Đã hiểu</button></footer></section></div>;
}

export default App;
