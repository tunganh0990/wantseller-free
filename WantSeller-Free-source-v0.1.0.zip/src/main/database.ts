import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import { DatabaseSync } from "node:sqlite";

export type Platform = "shopee-vn" | "tiktok-vn" | "lazada-vn";
export type ShopStatus = "disconnected" | "connected" | "needs-auth";

export type Shop = {
  id: string;
  name: string;
  platform: Platform;
  status: ShopStatus;
  createdAt: string;
};

export type Order = {
  id: string;
  shopId: string;
  externalId: string;
  status: string;
  orderDate: string | null;
  itemCount: number;
  totalCents: number;
  platformFeeCents: number;
  costCents: number;
  shippingCents: number;
  trackingCode: string;
  importedAt: string;
};

export type PrintDocument = {
  id: string;
  shopId: string | null;
  filePath: string;
  fileName: string;
  sizeBytes: number;
  pageCount: number;
  indexedAt: string | null;
  importedAt: string;
};

export type IndexedPdfPage = { documentId: string; pageNumber: number; text: string; fileName: string };

export type ReplyTemplate = {
  id: string;
  title: string;
  content: string;
  platform: Platform | "all";
  updatedAt: string;
};

export type AutomationPlan = {
  id: string;
  kind: "boost" | "flash-sale" | "rating" | "chat-replies";
  name: string;
  notes: string;
  enabled: number;
  updatedAt: string;
};

let connection: DatabaseSync | undefined;

export function openDatabase(path: string): void {
  if (connection) return;

  mkdirSync(dirname(path), { recursive: true });
  connection = new DatabaseSync(path);
  connection.exec("PRAGMA foreign_keys = ON;");
  connection.exec("PRAGMA journal_mode = WAL;");
  connection.exec("PRAGMA busy_timeout = 5000;");
  connection.exec([
    "CREATE TABLE IF NOT EXISTS schema_migrations (",
    "  version INTEGER PRIMARY KEY,",
    "  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
    ");",
    "CREATE TABLE IF NOT EXISTS shops (",
    "  id TEXT PRIMARY KEY,",
    "  name TEXT NOT NULL,",
    "  platform TEXT NOT NULL CHECK (platform IN ('shopee-vn', 'tiktok-vn', 'lazada-vn')),",
    "  status TEXT NOT NULL DEFAULT 'disconnected' CHECK (status IN ('disconnected', 'connected', 'needs-auth')),",
    "  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,",
    "  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,",
    "  UNIQUE(platform, name)",
    ");",
    "CREATE INDEX IF NOT EXISTS idx_shops_platform ON shops(platform, name COLLATE NOCASE);",
    "CREATE TABLE IF NOT EXISTS settings (",
    "  key TEXT PRIMARY KEY,",
    "  value_json TEXT NOT NULL,",
    "  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
    ");",
    "CREATE TABLE IF NOT EXISTS orders (",
    "  id TEXT PRIMARY KEY,",
    "  shop_id TEXT NOT NULL REFERENCES shops(id) ON DELETE CASCADE,",
    "  external_id TEXT NOT NULL,",
    "  status TEXT NOT NULL DEFAULT 'Chưa phân loại',",
    "  order_date TEXT,",
    "  item_count INTEGER NOT NULL DEFAULT 0,",
    "  total_cents INTEGER NOT NULL DEFAULT 0,",
    "  platform_fee_cents INTEGER NOT NULL DEFAULT 0,",
    "  cost_cents INTEGER NOT NULL DEFAULT 0,",
    "  shipping_cents INTEGER NOT NULL DEFAULT 0,",
    "  tracking_code TEXT NOT NULL DEFAULT '',",
    "  imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,",
    "  UNIQUE(shop_id, external_id)",
    ");",
    "CREATE INDEX IF NOT EXISTS idx_orders_shop_date ON orders(shop_id, order_date DESC);",
    "CREATE TABLE IF NOT EXISTS print_documents (",
    "  id TEXT PRIMARY KEY,",
    "  shop_id TEXT REFERENCES shops(id) ON DELETE SET NULL,",
    "  file_path TEXT NOT NULL UNIQUE,",
    "  file_name TEXT NOT NULL,",
    "  size_bytes INTEGER NOT NULL,",
    "  page_count INTEGER NOT NULL DEFAULT 0,",
    "  indexed_at TEXT,",
    "  imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
    ");",
    "CREATE TABLE IF NOT EXISTS print_document_pages (",
    "  document_id TEXT NOT NULL REFERENCES print_documents(id) ON DELETE CASCADE,",
    "  page_number INTEGER NOT NULL CHECK (page_number > 0),",
    "  text_content TEXT NOT NULL DEFAULT '',",
    "  PRIMARY KEY(document_id, page_number)",
    ");",
    "CREATE TABLE IF NOT EXISTS reply_templates (",
    "  id TEXT PRIMARY KEY,",
    "  title TEXT NOT NULL,",
    "  content TEXT NOT NULL,",
    "  platform TEXT NOT NULL DEFAULT 'all',",
    "  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
    ");",
    "CREATE TABLE IF NOT EXISTS automation_plans (",
    "  id TEXT PRIMARY KEY,",
    "  kind TEXT NOT NULL CHECK (kind IN ('boost', 'flash-sale', 'rating', 'chat-replies')),",
    "  name TEXT NOT NULL,",
    "  notes TEXT NOT NULL DEFAULT '',",
    "  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled IN (0, 1)),",
    "  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP",
    ");",
    "INSERT OR IGNORE INTO schema_migrations(version) VALUES (1);",
    "INSERT OR IGNORE INTO schema_migrations(version) VALUES (2);",
  ].join("\n"));
  const printColumns = connection.prepare("PRAGMA table_info(print_documents)").all() as Array<{ name: string }>;
  if (!printColumns.some((column) => column.name === "page_count")) connection.exec("ALTER TABLE print_documents ADD COLUMN page_count INTEGER NOT NULL DEFAULT 0");
  if (!printColumns.some((column) => column.name === "indexed_at")) connection.exec("ALTER TABLE print_documents ADD COLUMN indexed_at TEXT");
}

export function listOrders(shopId?: string): Order[] {
  return requireConnection().prepare([
    "SELECT id, shop_id AS shopId, external_id AS externalId, status, order_date AS orderDate,",
    "item_count AS itemCount, total_cents AS totalCents, platform_fee_cents AS platformFeeCents,",
    "cost_cents AS costCents, shipping_cents AS shippingCents, tracking_code AS trackingCode, imported_at AS importedAt",
    "FROM orders", shopId ? "WHERE shop_id = ?" : "", "ORDER BY order_date DESC, imported_at DESC",
  ].filter(Boolean).join(" ")).all(...(shopId ? [shopId] : [])) as unknown as Order[];
}

export function importOrders(rows: Array<Omit<Order, "id" | "importedAt"> & { id: string }>): { imported: number; updated: number } {
  const db = requireConnection();
  const statement = db.prepare([
    "INSERT INTO orders (id, shop_id, external_id, status, order_date, item_count, total_cents, platform_fee_cents, cost_cents, shipping_cents, tracking_code)",
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    "ON CONFLICT(shop_id, external_id) DO UPDATE SET status=excluded.status, order_date=excluded.order_date,",
    "item_count=excluded.item_count, total_cents=excluded.total_cents, platform_fee_cents=excluded.platform_fee_cents,",
    "cost_cents=excluded.cost_cents, shipping_cents=excluded.shipping_cents, tracking_code=excluded.tracking_code, imported_at=CURRENT_TIMESTAMP",
  ].join(" "));
  let imported = 0;
  let updated = 0;
  db.exec("BEGIN IMMEDIATE");
  try {
    for (const row of rows) {
      const existed = db.prepare("SELECT 1 FROM orders WHERE shop_id = ? AND external_id = ?").get(row.shopId, row.externalId);
      statement.run(row.id, row.shopId, row.externalId, row.status, row.orderDate, row.itemCount, row.totalCents, row.platformFeeCents, row.costCents, row.shippingCents, row.trackingCode);
      if (existed) updated += 1;
      else imported += 1;
    }
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  return { imported, updated };
}

export function listPrintDocuments(shopId?: string): PrintDocument[] {
  return requireConnection().prepare([
    "SELECT id, shop_id AS shopId, file_path AS filePath, file_name AS fileName, size_bytes AS sizeBytes, page_count AS pageCount, indexed_at AS indexedAt, imported_at AS importedAt",
    "FROM print_documents", shopId ? "WHERE shop_id = ? OR shop_id IS NULL" : "", "ORDER BY imported_at DESC",
  ].filter(Boolean).join(" ")).all(...(shopId ? [shopId] : [])) as unknown as PrintDocument[];
}

export function addPrintDocument(doc: Pick<PrintDocument, "id" | "shopId" | "filePath" | "fileName" | "sizeBytes">): void {
  requireConnection().prepare([
    "INSERT INTO print_documents (id, shop_id, file_path, file_name, size_bytes) VALUES (?, ?, ?, ?, ?)",
    "ON CONFLICT(file_path) DO NOTHING",
  ].join(" ")).run(doc.id, doc.shopId, doc.filePath, doc.fileName, doc.sizeBytes);
}

export function removePrintDocument(id: string): void {
  requireConnection().prepare("DELETE FROM print_documents WHERE id = ?").run(id);
}

export function getPrintDocumentPath(id: string): string | undefined {
  const row = requireConnection().prepare("SELECT file_path AS filePath FROM print_documents WHERE id = ?").get(id) as { filePath: string } | undefined;
  return row?.filePath;
}

export function savePdfIndex(id: string, pages: Array<{ pageNumber: number; text: string }>): void {
  const db = requireConnection();
  db.exec("BEGIN IMMEDIATE");
  try {
    db.prepare("DELETE FROM print_document_pages WHERE document_id=?").run(id);
    const insert = db.prepare("INSERT INTO print_document_pages (document_id, page_number, text_content) VALUES (?, ?, ?)");
    for (const page of pages) insert.run(id, page.pageNumber, page.text);
    db.prepare("UPDATE print_documents SET page_count=?, indexed_at=CURRENT_TIMESTAMP WHERE id=?").run(pages.length, id);
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

export function listIndexedPdfPages(): IndexedPdfPage[] {
  return requireConnection().prepare([
    "SELECT p.document_id AS documentId, p.page_number AS pageNumber, p.text_content AS text, d.file_name AS fileName",
    "FROM print_document_pages p JOIN print_documents d ON d.id=p.document_id ORDER BY d.file_name COLLATE NOCASE, p.page_number",
  ].join(" ")).all() as unknown as IndexedPdfPage[];
}

export function listReplyTemplates(): ReplyTemplate[] {
  return requireConnection().prepare("SELECT id, title, content, platform, updated_at AS updatedAt FROM reply_templates ORDER BY updated_at DESC").all() as unknown as ReplyTemplate[];
}

export function saveReplyTemplate(input: ReplyTemplate): ReplyTemplate {
  requireConnection().prepare([
    "INSERT INTO reply_templates (id, title, content, platform) VALUES (?, ?, ?, ?)",
    "ON CONFLICT(id) DO UPDATE SET title=excluded.title, content=excluded.content, platform=excluded.platform, updated_at=CURRENT_TIMESTAMP",
  ].join(" ")).run(input.id, input.title, input.content, input.platform);
  return requireConnection().prepare("SELECT id, title, content, platform, updated_at AS updatedAt FROM reply_templates WHERE id=?").get(input.id) as unknown as ReplyTemplate;
}

export function deleteReplyTemplate(id: string): void {
  requireConnection().prepare("DELETE FROM reply_templates WHERE id = ?").run(id);
}

export function listAutomationPlans(kind: AutomationPlan["kind"]): AutomationPlan[] {
  return requireConnection().prepare("SELECT id, kind, name, notes, enabled, updated_at AS updatedAt FROM automation_plans WHERE kind = ? ORDER BY updated_at DESC").all(kind) as unknown as AutomationPlan[];
}

export function saveAutomationPlan(plan: AutomationPlan): AutomationPlan {
  requireConnection().prepare([
    "INSERT INTO automation_plans (id, kind, name, notes, enabled) VALUES (?, ?, ?, ?, ?)",
    "ON CONFLICT(id) DO UPDATE SET name=excluded.name, notes=excluded.notes, enabled=excluded.enabled, updated_at=CURRENT_TIMESTAMP",
  ].join(" ")).run(plan.id, plan.kind, plan.name, plan.notes, plan.enabled);
  return requireConnection().prepare("SELECT id, kind, name, notes, enabled, updated_at AS updatedAt FROM automation_plans WHERE id=?").get(plan.id) as unknown as AutomationPlan;
}

export function deleteAutomationPlan(id: string): void {
  requireConnection().prepare("DELETE FROM automation_plans WHERE id=?").run(id);
}

function requireConnection(): DatabaseSync {
  if (!connection) throw new Error("Database has not been initialized");
  return connection;
}

export function listShops(): Shop[] {
  return requireConnection().prepare([
    "SELECT id, name, platform, status, created_at AS createdAt",
    "FROM shops ORDER BY name COLLATE NOCASE",
  ].join(" ")).all() as unknown as Shop[];
}

export function createShop(input: {
  id: string;
  name: string;
  platform: Platform;
}): Shop {
  const db = requireConnection();
  db.prepare(
    "INSERT INTO shops (id, name, platform) VALUES (?, ?, ?)",
  ).run(input.id, input.name, input.platform);

  const shop = db.prepare([
    "SELECT id, name, platform, status, created_at AS createdAt",
    "FROM shops WHERE id = ?",
  ].join(" ")).get(input.id) as unknown as Shop | undefined;

  if (!shop) throw new Error("Shop was not saved");
  return shop;
}
