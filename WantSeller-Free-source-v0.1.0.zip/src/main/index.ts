import { app, BrowserWindow, dialog, ipcMain, shell } from "electron";
import { randomUUID } from "node:crypto";
import { readFile, stat, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { z } from "zod";
import {
  addPrintDocument,
  createShop,
  deleteAutomationPlan,
  deleteReplyTemplate,
  getPrintDocumentPath,
  importOrders,
  listAutomationPlans,
  listIndexedPdfPages,
  listOrders,
  listPrintDocuments,
  listReplyTemplates,
  listShops,
  openDatabase,
  removePrintDocument,
  saveAutomationPlan,
  savePdfIndex,
  saveReplyTemplate,
  type AutomationPlan,
} from "./database";

const createShopSchema = z.object({
  name: z.string().trim().min(1).max(80),
  platform: z.enum(["shopee-vn", "tiktok-vn", "lazada-vn"]),
});

const platformSchema = z.enum(["shopee-vn", "tiktok-vn", "lazada-vn"]);
const planKindSchema = z.enum(["boost", "flash-sale", "rating", "chat-replies"]);
const templateSchema = z.object({
  id: z.string().uuid().optional(),
  title: z.string().trim().min(1).max(80),
  content: z.string().trim().min(1).max(4000),
  platform: z.union([platformSchema, z.literal("all")]),
});
const planSchema = z.object({
  id: z.string().uuid().optional(),
  kind: planKindSchema,
  name: z.string().trim().min(1).max(100),
  notes: z.string().max(4000).default(""),
  enabled: z.boolean().default(false),
});
const pdfIndexSchema = z.object({
  id: z.string().uuid(),
  pages: z.array(z.object({
    pageNumber: z.number().int().min(1).max(2000),
    text: z.string().max(60_000),
  })).max(2000),
});

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  const input = text.replace(/^\uFEFF/, "");
  const headerLine = input.split(/\r?\n/, 1)[0] ?? "";
  const delimiter = ([",", ";", "\t"] as const)
    .map((character) => ({ character, count: [...headerLine].filter((item) => item === character).length }))
    .sort((left, right) => right.count - left.count)[0]?.character ?? ",";
  let row: string[] = [];
  let field = "";
  let quoted = false;
  for (let i = 0; i < input.length; i += 1) {
    const char = input[i];
    if (quoted) {
      if (char === '"' && input[i + 1] === '"') { field += '"'; i += 1; }
      else if (char === '"') quoted = false;
      else field += char;
    } else if (char === '"' && field.length === 0) quoted = true;
    else if (char === delimiter) {
      row.push(field.trim()); field = "";
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && input[i + 1] === "\n") i += 1;
      row.push(field.trim()); field = "";
      if (row.some((cell) => cell.length > 0)) rows.push(row);
      row = [];
    } else field += char;
  }
  row.push(field.trim());
  if (row.some((cell) => cell.length > 0)) rows.push(row);
  if (quoted) throw new Error("CSV có dấu ngoặc kép chưa đóng");
  return rows;
}

function normalizedHeader(value: string): string {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function moneyCents(value: string | undefined): number {
  if (!value) return 0;
  const raw = value.replace(/[₫đ\s]/gi, "");
  const lastSeparator = Math.max(raw.lastIndexOf(","), raw.lastIndexOf("."));
  const fractionDigits = lastSeparator < 0 ? 0 : raw.length - lastSeparator - 1;
  let normalized = raw.replace(/[^\d.,-]/g, "");
  if (lastSeparator >= 0 && fractionDigits > 0 && fractionDigits <= 2) {
    const decimalSeparator = raw[lastSeparator];
    normalized = normalized.replace(decimalSeparator === "." ? /,/g : /\./g, "");
    if (decimalSeparator === ",") normalized = normalized.replace(",", ".");
  } else {
    normalized = normalized.replace(/[.,]/g, "");
  }
  const amount = Number(normalized);
  if (!Number.isFinite(amount) || amount < 0) return 0;
  return Math.round(amount * 100);
}

function csvCell(value: unknown): string {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function registerIpc(): void {
  ipcMain.handle("app:get-info", () => ({
    name: "WantSeller",
    version: app.getVersion(),
    mode: "free",
    dataPath: app.getPath("userData"),
  }));

  ipcMain.handle("shops:list", () => listShops());
  ipcMain.handle("shops:create", (_event, payload: unknown) => {
    const input = createShopSchema.parse(payload);
    return createShop({ id: randomUUID(), ...input });
  });

  ipcMain.handle("orders:list", (_event, shopId: unknown) => {
    const id = shopId === null || shopId === undefined ? undefined : z.string().uuid().parse(shopId);
    return listOrders(id);
  });

  ipcMain.handle("orders:import-csv", async (_event, shopId: unknown) => {
    const id = z.string().uuid().parse(shopId);
    const chosen = await dialog.showOpenDialog({
      title: "Chọn CSV đơn hàng",
      properties: ["openFile"],
      filters: [{ name: "CSV hoặc văn bản", extensions: ["csv", "txt"] }],
    });
    if (chosen.canceled || !chosen.filePaths[0]) return { imported: 0, updated: 0, canceled: true };
    const rows = parseCsv(await readFile(chosen.filePaths[0], "utf8"));
    if (rows.length < 2) throw new Error("Tệp không có dòng dữ liệu");
    if (rows.length > 20_001) throw new Error("Mỗi lần chỉ nhập tối đa 20.000 đơn");
    const headers = rows[0].map(normalizedHeader);
    const index = (names: string[]) => headers.findIndex((header) => names.includes(header));
    const column = {
      externalId: index(["orderid", "madonhang", "masodon", "ordernumber"]),
      status: index(["status", "trangthai", "orderstatus"]),
      orderDate: index(["orderdate", "ngaydat", "createdat", "ngaytao"]),
      itemCount: index(["itemcount", "soluong", "quantity"]),
      total: index(["total", "totalvnd", "tongtien", "tongtienvnd", "thanhtien", "thanhtienvnd", "ordervalue", "ordervaluevnd"]),
      fee: index(["platformfee", "platformfeevnd", "phisan", "phisanvnd", "phisanenang", "phisanenangvnd", "marketplacefee", "marketplacefeevnd"]),
      cost: index(["cost", "costvnd", "giavon", "giavonvnd", "productcost", "productcostvnd"]),
      shipping: index(["shipping", "shippingvnd", "phivanchuyen", "phivanchuyenvnd", "shippingfee", "shippingfeevnd"]),
      tracking: index(["trackingcode", "mavandon", "waybill"]),
    };
    if (column.externalId < 0) throw new Error("Không tìm thấy cột Mã đơn hàng / order_id");
    const mapped = rows.slice(1).map((cells, rowIndex) => {
      const get = (position: number) => position < 0 ? "" : (cells[position] ?? "");
      const externalId = get(column.externalId).trim();
      if (!externalId) throw new Error(`Dòng ${rowIndex + 2}: thiếu mã đơn hàng`);
      const countValue = Number(get(column.itemCount) || 0);
      return {
        id: randomUUID(), shopId: id, externalId: externalId.slice(0, 120),
        status: (get(column.status) || "Chưa phân loại").slice(0, 80),
        orderDate: get(column.orderDate).slice(0, 40) || null,
        itemCount: Number.isFinite(countValue) && countValue >= 0 ? Math.floor(countValue) : 0,
        totalCents: moneyCents(get(column.total)), platformFeeCents: moneyCents(get(column.fee)),
        costCents: moneyCents(get(column.cost)), shippingCents: moneyCents(get(column.shipping)),
        trackingCode: get(column.tracking).slice(0, 120),
      };
    });
    return { ...importOrders(mapped), canceled: false };
  });

  ipcMain.handle("orders:export-csv", async (_event, shopId: unknown) => {
    const id = shopId === null || shopId === undefined ? undefined : z.string().uuid().parse(shopId);
    const orders = listOrders(id);
    const header = ["order_id", "status", "order_date", "item_count", "total_vnd", "platform_fee_vnd", "cost_vnd", "shipping_vnd", "tracking_code"];
    const body = orders.map((order) => [order.externalId, order.status, order.orderDate, order.itemCount, order.totalCents / 100, order.platformFeeCents / 100, order.costCents / 100, order.shippingCents / 100, order.trackingCode].map(csvCell).join(","));
    const chosen = await dialog.showSaveDialog({
      title: "Xuất danh sách đơn hàng",
      defaultPath: "wantseller-orders.csv",
      filters: [{ name: "CSV", extensions: ["csv"] }],
    });
    if (chosen.canceled || !chosen.filePath) return { canceled: true, count: 0 };
    await writeFile(chosen.filePath, "\uFEFF" + [header.join(","), ...body].join("\r\n"), "utf8");
    return { canceled: false, count: orders.length };
  });

  ipcMain.handle("documents:list", (_event, shopId: unknown) => {
    const id = shopId === null || shopId === undefined ? undefined : z.string().uuid().parse(shopId);
    return listPrintDocuments(id);
  });
  ipcMain.handle("documents:indexed-pages", () => listIndexedPdfPages());
  ipcMain.handle("documents:pdf-data", async (_event, documentId: unknown) => {
    const id = z.string().uuid().parse(documentId);
    const filePath = getPrintDocumentPath(id);
    if (!filePath) throw new Error("Không tìm thấy tài liệu trong kho");
    const fileStat = await stat(filePath);
    if (fileStat.size > 50 * 1024 * 1024) throw new Error("PDF lớn hơn giới hạn lập chỉ mục 50 MB");
    return readFile(filePath);
  });
  ipcMain.handle("documents:save-index", (_event, payload: unknown) => {
    const input = pdfIndexSchema.parse(payload);
    if (input.pages.reduce((sum, page) => sum + page.text.length, 0) > 10_000_000) throw new Error("Nội dung PDF vượt giới hạn lập chỉ mục");
    savePdfIndex(input.id, input.pages);
  });
  ipcMain.handle("documents:import", async (_event, shopId: unknown) => {
    const id = shopId === null || shopId === undefined ? null : z.string().uuid().parse(shopId);
    const chosen = await dialog.showOpenDialog({
      title: "Thêm phiếu PDF vào kho",
      properties: ["openFile", "multiSelections"],
      filters: [{ name: "PDF", extensions: ["pdf"] }],
    });
    if (chosen.canceled) return { canceled: true, count: 0 };
    const beforeCount = listPrintDocuments().length;
    for (const filePath of chosen.filePaths) {
      const fileStat = await stat(filePath);
      if (fileStat.size > 50 * 1024 * 1024) continue;
      addPrintDocument({ id: randomUUID(), shopId: id, filePath, fileName: filePath.split(/[\\/]/).pop() ?? "Phiếu PDF", sizeBytes: fileStat.size });
    }
    return { canceled: false, count: Math.max(0, listPrintDocuments().length - beforeCount) };
  });
  ipcMain.handle("documents:open", async (_event, documentId: unknown) => {
    const id = z.string().uuid().parse(documentId);
    const filePath = getPrintDocumentPath(id);
    if (!filePath) throw new Error("Không tìm thấy tài liệu trong kho");
    return shell.openPath(filePath);
  });
  ipcMain.handle("documents:remove", (_event, documentId: unknown) => removePrintDocument(z.string().uuid().parse(documentId)));

  ipcMain.handle("templates:list", () => listReplyTemplates());
  ipcMain.handle("templates:save", (_event, payload: unknown) => {
    const input = templateSchema.parse(payload);
    return saveReplyTemplate({ id: input.id ?? randomUUID(), ...input, updatedAt: new Date().toISOString() });
  });
  ipcMain.handle("templates:delete", (_event, id: unknown) => deleteReplyTemplate(z.string().uuid().parse(id)));

  ipcMain.handle("plans:list", (_event, kind: unknown) => listAutomationPlans(planKindSchema.parse(kind)));
  ipcMain.handle("plans:save", (_event, payload: unknown) => {
    const input = planSchema.parse(payload);
    const plan: AutomationPlan = { id: input.id ?? randomUUID(), kind: input.kind, name: input.name, notes: input.notes, enabled: input.enabled ? 1 : 0, updatedAt: new Date().toISOString() };
    return saveAutomationPlan(plan);
  });
  ipcMain.handle("plans:delete", (_event, id: unknown) => deleteAutomationPlan(z.string().uuid().parse(id)));
  ipcMain.handle("app:show-data-folder", () => shell.openPath(app.getPath("userData")));

  ipcMain.handle("window:control", (event, control: unknown) => {
    if (control !== "minimize" && control !== "toggle-maximize" && control !== "close") {
      throw new Error("Unsupported window control");
    }

    const window = BrowserWindow.fromWebContents(event.sender);
    if (!window) return;
    if (control === "minimize") window.minimize();
    if (control === "toggle-maximize") {
      if (window.isMaximized()) window.unmaximize();
      else window.maximize();
    }
    if (control === "close") window.close();
  });
}

function createMainWindow(): void {
  const window = new BrowserWindow({
    width: 1420,
    height: 900,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: "#f5f6f8",
    title: "WantSeller",
    icon: join(app.isPackaged ? process.resourcesPath : app.getAppPath(), app.isPackaged ? "icon.ico" : join("build", "icon.ico")),
    webPreferences: {
      preload: join(import.meta.dirname, "../preload/index.cjs"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
    },
  });

  const devRendererUrl = process.env.ELECTRON_RENDERER_URL;
  window.webContents.on("will-navigate", (event, targetUrl) => {
    const allowed = devRendererUrl
      ? new URL(targetUrl).origin === new URL(devRendererUrl).origin
      : targetUrl.startsWith("file://");
    if (!allowed) event.preventDefault();
  });
  window.webContents.setWindowOpenHandler(() => ({ action: "deny" }));

  if (devRendererUrl) {
    void window.loadURL(devRendererUrl);
  } else {
    void window.loadFile(join(import.meta.dirname, "../renderer/index.html"));
  }
}

app.whenReady().then(() => {
  app.setName("WantSeller");
  const developmentDataPath = !app.isPackaged ? process.env.WANTSELLER_DATA_DIR?.trim() : undefined;
  app.setPath("userData", developmentDataPath ? resolve(developmentDataPath) : join(app.getPath("appData"), "WantSeller-Free"));
  openDatabase(join(app.getPath("userData"), "wantseller-free.sqlite"));
  registerIpc();
  createMainWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
