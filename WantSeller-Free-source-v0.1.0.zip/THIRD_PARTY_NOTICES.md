# Third-party and reference asset notices

## WantSeller reference UI and assets

Files in `src/renderer/assets/reference/` and `build/icon.ico` reproduce selected interface styles, marketplace icons, and the application icon from WantSeller 1.5.0. The project owner confirmed that their purchase terms authorize copying, modifying, and publicly releasing these materials. They are excluded from the repository's MIT license and are not relicensed here. The rest of this repository is a new implementation. WantSeller is not represented as the original vendor's official free build.

## Marketplace marks

Shopee, TikTok Shop, and Lazada names and logos identify the platforms supported as local data labels. Their respective owners retain their marks. This project is not affiliated with or endorsed by those companies.

## PDF.js

The PDF viewer and text indexing use `pdfjs-dist` 6.5.438 by Mozilla and individual contributors, licensed under Apache License 2.0. The worker is bundled locally in the application. The full license text is included in [`licenses/PDF.js-Apache-2.0.txt`](licenses/PDF.js-Apache-2.0.txt).

## Other runtime dependencies

| Package | License | Purpose |
|---|---|---|
| Electron | MIT | Windows desktop runtime |
| React and React DOM | MIT | UI rendering |
| Lucide React | ISC | UI icons |
| Zod | MIT | Input validation |

Build-time dependencies are recorded in `package-lock.json`. Each package's license metadata remains in npm's package manifest.
